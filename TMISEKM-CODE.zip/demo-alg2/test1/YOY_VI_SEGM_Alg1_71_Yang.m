function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_71_Yang(m)
clc;
k       = 10;
% m       = 100;
lamda1  = 1.1;
miu     = 0.1;
x1      = ones(m,1);
iter    = 1;
lamdan  = lamda1;
xn      = x1;
pn      = xn - lamdan*A1(xn,m);
yn      = Proj_Poly(pn,m,k);
xnp1    = PTn1(xn - lamdan*A1(yn,m),xn,yn,lamdan,m);
rn1     = A1(xn,m) - A1(yn,m);
rn2     = xn - yn;
rn3     = xnp1 - yn;
rnn     = norm(rn2,2);
rn      = dot(rn1,rn3);
if rn > 0
    lamdanp1 = min(miu*(norm(rn2,2)^2+norm(rn3,2)^2)/(2*rn),lamdan);
else
    lamdanp1 = lamdan;
end
check    = rnn;
changex  = rnn;
sol1     = [iter,changex];
tic
while check > 1e-5
    xn      = xnp1;
    lamdan  = lamdanp1;
    iter    = iter+1;
    pn      = xn - lamdan*A1(xn,m);
    yn      = Proj_Poly(pn,m,k);
    xnp1    = PTn1(xn - lamdan*A1(yn,m),xn,yn,lamdan,m);
    rn1     = A1(xn,m) - A1(yn,m);
    rn2     = xn - yn;
    rn3     = xnp1 - yn;
    rnn     = norm(rn2,2);
    rn      = dot(rn1,rn3);
    if rn > 0
        lamdanp1 = min(miu*(norm(rn2,2)^2+norm(rn3,2)^2)/(2*rn),lamdan);
    else
        lamdanp1 = lamdan;
    end
    changex  = rnn;
    check    = rnn;
    sol1     = [sol1;[iter,changex]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on
% 
