function [xnp1, iter, Time, sol1] = TwoStep_Inertial_SEGM_KM_1(m)
% Double Two-step Inertial Subgradient Extragradient Method with Adaptive Step Size
% 对应论文中的 Algorithm: Double Two-step Inertial Subgradient Extragradient Method
% 注意：x_{n+1} = (1 - a_n) x_n + a_n u_n
clc;

%% ========== 参数设置 ==========
k        = 10;          % 多面体约束参数
% m      = 100;         % 维度 (输入参数)

% 算法参数 (Require)
mu       = 0.1;         % mu in (0,1)
lambda1  = 1.1;         % 初始步长 lambda_1 > 0

% 双惯性参数 theta_n^1, theta_n^2 (可随时间变化)
theta1   = 0.99;         % theta_n^1
theta2   = 0.99;         % theta_n^2

% 组合系数 a_n (可随时间变化，通常 a_n in (0, 1/(1+epsilon)))
a_n      = 0.2966;         % a_n

%% ========== 初始化 ==========
x0       = ones(m,1);   % x_0
x1       = rand(m,1);   % x_1
xnm2     = x0;          % x_{-1} = x_0
xnm1     = x0;          % x_{n-1} = x_0 (n=1时)
xn       = x1;          % x_n = x_1

iter     = 1;
lambda_n = lambda1;

% 初始化序列 {x_n}, {y_n}, {gamma_n} 满足:
% x_n -> 0, y_n -> 1, sum gamma_n < infinity
gamma_n  = 1/(iter^2);   % gamma_n 满足 sum < infinity (p=2>1)
x_seq    = 1/iter;       % x_n -> 0
y_seq    = 1 + 1/iter;   % y_n -> 1

% 双惯性外推: w_n = x_n + theta1*(x_n - x_{n-1}) + theta2*(x_{n-1} - x_{n-2})
wn       = xn + theta1*(xn - xnm1) + theta2*(xnm1 - xnm2);

% 计算 y_n = P_C(w_n - lambda_n * A w_n)
pn       = wn - lambda_n * A1(wn, m);
yn       = Proj_Poly(pn, m, k);

% 计算残差
rn1      = A1(wn, m) - A1(yn, m);
rn2      = wn - yn;
rn       = norm(rn2, 2);

% 停止条件检查: w_n = y_n = x_n
if norm(wn - yn, 2) < 1e-12 && norm(wn - xn, 2) < 1e-12
    fprintf('算法在 n=%d 处终止: w_n = y_n = x_n\n', iter);
    xnp1 = xn;
    Time = 0;
    sol1 = [iter, rn];
    return;
end

% 自适应步长更新 (lambda_{n+1})
if norm(rn1, 2) == 0
    lambda_next = (1 + gamma_n) * lambda_n;
else
    lambda_next = min((x_seq + y_seq * mu) * rn / norm(rn1, 2), (1 + gamma_n) * lambda_n);
end

% 校正步: u_n = P_{T_n}(w_n - lambda_n * A y_n)
% 然后 x_{n+1} = (1 - a_n) * x_n + a_n * u_n  (注意：使用 x_n，不是 z_n)
u_n      = PTn1(wn - lambda_n * A1(yn, m), wn, yn, lambda_n, m);
xnp1     = (1 - a_n) * xn + a_n * u_n;

% 记录收敛历史
changex  = rn;
sol1     = [iter, changex];

%% ========== 主迭代循环 ==========
tic
max_iter = 500;       % 最大迭代次数
tol      = 1e-5;       % 容差

for n = 2:max_iter
    % 更新历史点
    xnm2    = xnm1;    % x_{n-2} <- x_{n-1}
    xnm1    = xn;      % x_{n-1} <- x_n
    xn      = xnp1;    % x_n <- x_{n+1}
    
    lambda_n = lambda_next;
    iter     = n;
    
    % 更新序列 (满足收敛条件)
    gamma_n  = 1/(iter^2);   % gamma_n 满足 sum < infinity (p=1.5>1)
    x_seq    = 1/iter;          % x_n -> 0
    y_seq    = 1 + 1/iter;      % y_n -> 1
    
    % 双惯性外推: w_n = x_n + theta1*(x_n - x_{n-1}) + theta2*(x_{n-1} - x_{n-2})
    wn       = xn + theta1 * (xn - xnm1) + theta2 * (xnm1 - xnm2);
    
    % 投影步: y_n = P_C(w_n - lambda_n * A w_n)
    pn       = wn - lambda_n * A1(wn, m);
    yn       = Proj_Poly(pn, m, k);
    
    % 计算残差
    rn1      = A1(wn, m) - A1(yn, m);
    rn2      = wn - yn;
    rn       = norm(rn2, 2);
    
    % 停止条件: w_n = y_n = x_n
    if rn < tol && norm(wn - xn, 2) < tol
        fprintf('算法在 n=%d 处终止: w_n = y_n = x_n, 残差 = %.2e\n', iter, rn);
        break;
    end
    
    % 自适应步长更新 (lambda_{n+1})
    if norm(rn1, 2) == 0
        lambda_next = (1 + gamma_n) * lambda_n;
    else
        lambda_next = min((x_seq + y_seq * mu) * rn / norm(rn1, 2), (1 + gamma_n) * lambda_n);
    end
    
    % 校正步: u_n = P_{T_n}(w_n - lambda_n * A y_n)
    u_n      = PTn1(wn - lambda_n * A1(yn, m), wn, yn, lambda_n, m);
    
    % 更新 x_{n+1} = (1 - a_n) * x_n + a_n * u_n
    xnp1     = (1 - a_n) * xn + a_n * u_n;
    
    % 记录收敛历史
    changex  = rn;
    sol1     = [sol1; [iter, changex]];
    
    % 提前终止条件
    if changex < tol
        fprintf('算法在 n=%d 处收敛, 残差 = %.2e\n', iter, changex);
        break;
    end
end

Time = toc;

fprintf('\n========== 算法终止信息 ==========\n');
fprintf('迭代次数: %d\n', iter);
fprintf('最终残差: %.2e\n', changex);
fprintf('运行时间: %.4f 秒\n', Time);
fprintf('最终步长: %.4f\n', lambda_n);
fprintf('==================================\n');

% 可选：绘制收敛图
% figure;
% loglog(sol1(:,1), sol1(:,2), '-b*', 'LineWidth', 2, 'MarkerSize', 7);
% xlabel('Number of iterations', 'FontSize', 16, 'interpreter', 'latex');
% ylabel('$||x_{n+1}-x_n||_2$', 'FontSize', 16, 'interpreter', 'latex');
% grid on;

end