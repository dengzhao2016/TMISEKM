function [xnp1, iter, Time, sol1] = SEAP_Alg1_71(m,o)
% SEAP Algorithm 1 from the paper:
% "Strongly Convergent Inertial Corrected Subgradient Extragradient Algorithm 
% with Past Extrapolation: Theory and Applications"
%
% Input:
%   m - dimension of the problem
% Output:
%   xnp1   - final iterate (approximate solution)
%   iter   - number of iterations performed
%   Time   - CPU time elapsed
%   sol1   - history of [iteration, change in x]

clc;

% ========================
% Parameter initialization (following the paper)
% ========================
lambda_minus1 = 1e-3;           % lambda_{-1}
alpha_k       = @(k) 1/(k+1);   % alpha_k = 1/(k+1)
beta_k        = @(k) 1/(k+1)^3; % beta_k summable
mu            = 1e-8;              % mu parameter (small, as suggested in paper)

% ========================
% Initial points
% ========================
x0      = ones(m,1);            % x_0
x_minus1 = zeros(m,1);          % x_{-1}
y_minus1 = zeros(m,1);          % y_{-1}

% ========================
% Variables initialization
% ========================
k           = 0;                % iteration counter
xkm1        = x_minus1;         % x_{k-1}
xk          = x0;               % x_k
ykm1        = y_minus1;         % y_{k-1}
lambdakm1   = lambda_minus1;    % lambda_{k-1}

iter    = 1;
changex = 1;
sol1    = [];

tic;

while changex > 1e-6 && iter <= 300
    
    % ============================================
    % Step 2: Compute y_k using past extrapolation
    % Formula (10) in the paper:
    % y_k = P_C( x_k + (k-1)/(k+2)*(x_k - x_{k-1}) 
    %            + (k+1)/(k+2)*(x_k - y_{k-1}) - lambda_{k-1}*F(y_{k-1}) )
    % ============================================
    coeff1 = (k-1)/(k+2);           % (k-1)/(k+2)
    coeff2 = (k+1)/(k+2);           % (k+1)/(k+2)
    
    extrap = coeff1*(xk - xkm1) + coeff2*(xk - ykm1);
    arg_yk = xk + extrap - lambdakm1 * A1(ykm1, m);
    yk = Proj_Poly(arg_yk, m, o);         % Proj_Poly
    
    % ============================================
    % Step 3: Adaptive step size update
    % Formula (11) in the paper
    % ============================================
    Fyk     = A1(yk, m);
    Fykm1   = A1(ykm1, m);
    norm_y_diff = norm(yk - ykm1);
    norm_F_diff = norm(Fyk - Fykm1);
    
    if norm_F_diff > mu * norm_y_diff / lambdakm1
        lambdak = mu * norm_y_diff / (2* norm_F_diff);
    else
        lambdak = (1 + beta_k(k)) * lambdakm1;
    end
    
    % ============================================
    % Halpern-type point u_k
    % Formula (12) in the paper
    % ============================================
    alpha = alpha_k(k);
    uk = alpha * x0 + (1 - alpha) * xk;
    
    % ============================================
    % Step 4: Half-space T_k and projection onto T_k
    % T_k = { w : < u_k - lambda_k*(1-alpha_k)*F(y_{k-1}) - y_k, w - y_k > <= 0 }
    % x_{k+1} = P_{T_k}( u_k - lambda_k*(1-alpha_k)*F(y_k) )
    % ============================================
    dk = uk - lambdak * (1 - alpha) * Fykm1 - yk;
    
    vk = uk - lambdak * (1 - alpha) * Fyk;
    xkp1 = Proj_Tk(vk, yk, dk, m);
    
    % ============================================
    % Check convergence
    % ============================================
    changex = norm(xkp1 - xk);
    sol1 = [sol1; iter, changex];
    
    % ============================================
    % Update for next iteration
    % ============================================
    xkm1   = xk;
    xk     = xkp1;
    ykm1   = yk;
    lambdakm1 = lambdak;
    k = k + 1;
    iter = k;
end

Time = toc;
xnp1 = xk;

end





% ============================================================
% Subfunction: Projection onto half-space T_k
% T_k = { w : <d_k, w - y_k> <= 0 }
% Closed-form solution similar to PTn1 in your code
% ============================================================
function y = Proj_Tk(x, yk, dk, m)
    % x: point to project (vk)
    % yk: reference point
    % dk: normal vector of half-space
    
    b = dot(dk, yk);      % <dk, yk>
    inner = dot(dk, x);   % <dk, x>
    
    if inner > b
        y = x + (b - inner) * dk / (norm(dk)^2);
    else
        y = x;
    end
end

