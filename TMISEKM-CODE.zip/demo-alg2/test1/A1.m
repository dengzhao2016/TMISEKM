function y = A1(x, m, R, U, q)
% 修改后的 A1 函数，接受固定的 R, U, q 作为参数
% 如果不传参数，则生成新的（保持向后兼容）

if nargin < 5
    % 向后兼容：如果没有传入 R,U,q，则生成新的
    R = randn(m);
    U = randn(m);
    q = randn(m,1);
end

P = R' * R;
Q = U' * U;
alpha = 0.01;
w = -x' * Q * x;
y = (exp(w) + alpha) * (P * x + q);
end