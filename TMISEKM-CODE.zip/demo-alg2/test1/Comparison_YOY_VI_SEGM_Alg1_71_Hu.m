function Comparison_YOY_VI_SEGM_Alg1_71_Hu1
clc
m = 100;


[xnp1_YOY, iter_YOY, Time_YOY, sol_YOY] = YOY_VI_SEGM_Alg1_71(m);
[xnp1_YNS, iter_YNS, Time_YNS, sol_YNS] = YOY_VI_SEGM_Alg1_71_YNS(m);
[xnp1_Yang, iter_Yang, Time_Yang, sol_Yang] = YOY_VI_SEGM_Alg1_71_Yang(m);
[xnp1_Yang2, iter_Yang2, Time_Yang2, sol_Yang2] = YOY_VI_SEGM_Alg1_71_Yang2(m);%SEAP_Alg1_71(m,10)
[xnp1_Chang, iter_Chang, Time_Chang, sol_Chang] = YOY_VI_SEGM_Alg1_71_Chang(m);
[xnp1_Hu, iter_Hu, Time_Hu, sol_Hu] = TwoStep_Inertial_SEGM_KM_1(m);

% 显示结果
disp('========== 计算时间比较 ==========');
disp(['Time_YOY    = ', num2str(Time_YOY), ' 秒']);
disp(['Time_YNS    = ', num2str(Time_YNS), ' 秒']);
disp(['Time_Yang   = ', num2str(Time_Yang), ' 秒']);
disp(['Time_Yang2  = ', num2str(Time_Yang2), ' 秒']);
disp(['Time_Chang  = ', num2str(Time_Chang), ' 秒']);
disp(['Time_Hu     = ', num2str(Time_Hu), ' 秒']);

disp('========== 迭代次数比较 ==========');
disp(['iter_YOY    = ', num2str(iter_YOY)]);
disp(['iter_YNS    = ', num2str(iter_YNS)]);
disp(['iter_Yang   = ', num2str(iter_Yang)]);
disp(['iter_Yang2  = ', num2str(iter_Yang2)]);
disp(['iter_Chang  = ', num2str(iter_Chang)]);
disp(['iter_Hu     = ', num2str(iter_Hu)]);

figure;
% 先画你的算法 Two-Step-ISEKM（让它出现在图例第一位）
loglog(sol_Hu(:,1), sol_Hu(:,2), '-ro', 'LineWidth', 2, 'MarkerSize', 8); hold on;
% 再画其他算法
loglog(sol_YOY(:,1), sol_YOY(:,2), '-c*', 'LineWidth', 2, 'MarkerSize', 8);
loglog(sol_YNS(:,1), sol_YNS(:,2), '-b^', 'LineWidth', 2, 'MarkerSize', 8);
loglog(sol_Yang(:,1), sol_Yang(:,2), '-h', 'LineWidth', 2, 'MarkerSize', 8);
loglog(sol_Yang2(:,1), sol_Yang2(:,2), '-kp', 'LineWidth', 2, 'MarkerSize', 8);
loglog(sol_Chang(:,1), sol_Chang(:,2), '-md', 'LineWidth', 2, 'MarkerSize', 8);
hold off;

xlabel('Number of iterations', 'FontSize', 16, 'interpreter', 'latex')
ylabel('$||e_n||_2$', 'FontSize', 16, 'interpreter', 'latex')

% 图例顺序与绘图顺序一致：Two-Step-ISEKM 放在第一个
I = legend('Two-Step-ISEKM', 'Yoy Alg. ', 'Shehu Alg.', ...
           'Yang Alg.', 'Yang2 Alg.', 'Chang Alg.');
set(I, 'interpreter', 'latex', 'Location', 'northeast');
box off
grid on

end