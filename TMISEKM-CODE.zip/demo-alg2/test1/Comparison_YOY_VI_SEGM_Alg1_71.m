function Comparison_YOY_VI_SEGM_Alg1_71
clc
m = 100;

[xnp1_YOY, iter_YOY, Time_YOY, sol_YOY] = YOY_VI_SEGM_Alg1_71(m);
[xnp1_YNS, iter_YNS, Time_YNS, sol_YNS] = YOY_VI_SEGM_Alg1_71_YNS(m);
% [xnp1_Thong, iter_Thong, Time_Thong, sol_Thong] = YOY_VI_SEGM_Alg1_71_Thong(m);
[xnp1_Fan, iter_Fan, Time_Fan, sol_Fan] = YOY_VI_SEGM_Alg1_71_Thong(m);
[xnp1_Yang, iter_Yang, Time_Yang, sol_Yang] = YOY_VI_SEGM_Alg1_71_Yang(m);
[xnp1_Yang2, iter_Yang2, Time_Yang2, sol_Yang2] = YOY_VI_SEGM_Alg1_71_Yang2(m);
[xnp1_Chang, iter_Chang, Time_Chang, sol_Chang] = YOY_VI_SEGM_Alg1_71_Chang(m);





disp(['Time_YOY = ',num2str(Time_YOY)]);
disp(['Time_YNS = ',num2str(Time_YNS)]);
% disp(['Time_Thong = ',num2str(Time_Thong)])
disp(['Time_Fan = ',num2str(Time_Fan)]);
disp(['Time_Yang = ',num2str(Time_Yang)]);
disp(['Time_Yang2 = ',num2str(Time_Yang2)]);
disp(['Time_Chang = ',num2str(Time_Chang)]);


disp(['iter_YOY = ',num2str(iter_YOY)]);
disp(['iter_YNS = ',num2str(iter_YNS)]);
% disp(['iter_Thong = ',num2str(iter_Thong)]);
disp(['iter_Fan = ',num2str(iter_Fan)]);
disp(['iter_Yang = ',num2str(iter_Yang)]);
disp(['iter_Yang2 = ',num2str(iter_Yang2)]);
disp(['iter_Chang = ',num2str(iter_Chang)]);





% figure;
% loglog(sol_YNS(:,1),sol_YNS(:,2),'-b*',sol_Fan(:,1),sol_Fan(:,2),'-ro',sol_Thong(:,1),sol_Thong(:,2),'-gs',...
%     sol_Tian(:,1),sol_Tian(:,2),'-kp',sol_Yang(:,1),sol_Yang(:,2),'--m','LineWidth',2,'MarkerSize',7)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||e_n||_2$','FontSize',16,'interpreter','latex')
% I=legend('Proposed Alg. 1','Fan Alg.','Thong Alg.','Tian Alg.','Yang Alg.');
% set(I,'interpreter','latex');
% box off
% grid on

% figure;
% loglog(sol_YOY(:,1),sol_YOY(:,2),'-c*',sol_YNS(:,1),sol_YNS(:,2),'-b*',sol_Thong(:,1),sol_Thong(:,2),'-gs',...
%     sol_Fan(:,1),sol_Fan(:,2),'-kp',sol_Yang(:,1),sol_Yang(:,2),'-ro',sol_Yang2(:,1),sol_Yang2(:,2),'-yo',...
%     sol_Chang(:,1),sol_Chang(:,2),'-m*','LineWidth',2,'MarkerSize',7)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||e_n||_2$','FontSize',16,'interpreter','latex')
% I=legend('Proposed Alg. 1','Shehu Alg.','Thong Alg.','Fan Alg.','Yang Alg.','Yang2 Alg.','Chang Alg.');
% set(I,'interpreter','latex');
% box off
% grid on

% figure;
loglog(sol_YOY(:,1),sol_YOY(:,2),'-c*',sol_YNS(:,1),sol_YNS(:,2),'-b*',sol_Fan(:,1),sol_Fan(:,2),'-gs',...
    sol_Yang(:,1),sol_Yang(:,2),'-ro',sol_Yang2(:,1),sol_Yang2(:,2),'-kp',...
    sol_Chang(:,1),sol_Chang(:,2),'-m*','LineWidth',2,'MarkerSize',7)
xlabel('Number of iterations','FontSize',16,'interpreter','latex')
ylabel('$||e_n||_2$','FontSize',16,'interpreter','latex')
I=legend('Proposed Alg. 1','Shehu Alg.','Fan Alg.','Yang Alg.','Yang2 Alg.','Chang Alg.');
set(I,'interpreter','latex');
