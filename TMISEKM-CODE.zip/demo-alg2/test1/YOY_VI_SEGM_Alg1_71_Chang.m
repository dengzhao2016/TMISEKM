function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_71_Chang(m)
clc;
k        = 10;
% m        = 100;
lamda1   = 1.1;
alpha    = 0.343;
% delta    = 0.05;
% alpha    = 0.3;
delta    = 0.2;
n0       = 1000;
x0       = ones(m,1);
x1       = x0;
p1       = x1 - lamda1*A1(x1,m);
y1       = Proj_Poly(p1,m,k);
iter     = 1;
lamdan   = lamda1;
xnm1     = x0;
xn       = x1;
yn       = y1;
miun     = 1 + 1/(1 + fix(iter/n0));
rn       = xnm1 - xn;
wn       = xn + delta*rn;
pn       = wn - lamdan*A1(yn,m);
ynp1     = Proj_Poly(pn,m,k);
xnp1     = PTn1(wn - lamdan*A1(ynp1,m),wn,ynp1,lamdan,m);
rn1      = A1(ynp1,m) - A1(yn,m);
rn2      = ynp1 - yn;
if rn == 0
    lamdanp1 = lamdan*miun;
else
    lamdanp1 = min((alpha*norm(rn2,2))/norm(rn1,2),lamdan);
end
check    = norm(wn - yn,2);
changex  = norm(wn - yn,2);
sol1     = [iter,changex];
tic
while check > 1e-5
    xnm1     = xn;
    xn       = xnp1;
    yn       = ynp1;
    lamdan   = lamdanp1;
    iter     = iter+1;
    miun     = 1 + 1/(1 + fix(iter/n0));
    rn       = xnm1 - xn;
    wn       = xn + delta*rn;
    pn       = wn - lamdan*A1(yn,m);
    ynp1     = Proj_Poly(pn,m,k);
    xnp1     = PTn1(wn - lamdan*A1(ynp1,m),wn,ynp1,lamdan,m);
    rn1      = A1(ynp1,m) - A1(yn,m);
    rn2      = ynp1 - yn;
    if rn == 0
        lamdanp1 = lamdan*miun;
    else
        lamdanp1 = min((alpha*norm(rn2,2))/norm(rn1,2),lamdan);
    end
    changex  = norm(wn - yn,2);
    check    = norm(wn - yn,2);
    sol1     = [sol1;[iter,changex]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on

