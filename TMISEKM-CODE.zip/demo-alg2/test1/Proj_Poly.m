function [arg_x,val_p] = Proj_Poly(x,m,k)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function calculate the projection of a point x onto % 
% the polyhedron of the form Qx <= b                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

B     = rand(k,m);
b     = rand(k,1);
func  = @(y)(1/2)*(norm(y-x,2))^2;
%
[arg_x,val_p] = fmincon(func,x,B,b);
