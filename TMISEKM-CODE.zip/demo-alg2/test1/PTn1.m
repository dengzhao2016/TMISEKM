function y = PTn1(x,h1,h2,h3,m)
% h1 = wn; h2 = yn; h3 = lamdan
a      = h1 - h2 - h3*A1(h1,m);
b      = dot(a,h2);
innern = dot(a,x);
if innern > b
    y = x + (b - innern).*a/(norm(a,2).^2);
else
    y = x;
end