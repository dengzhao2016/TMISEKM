function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_71_Tian(m)
clc;
k       = 10;
m       = 100;
lamda1  = 1.1
thetan  = 0.25;
miu     = 0.1;
x0      = ones(m,1);
x1      = rand(m,1);
iter    = 1;
alphan  = 0.2;
lamdan  = lamda1;
xnm1    = x0;
xn      = x1;
wn      = xn + thetan*(xn-xnm1);
pn      = wn - lamdan*A1(wn,m);
yn      = Proj_Poly(pn,m,k);
rn1     = A1(wn,m)-A1(yn,m);
rn2     = wn - yn;
rn      = norm(rn2,2);
if rn1 == 0
    lamdanp1 = lamdan;
else
    lamdanp1 = min(miu*rn/norm(rn1,2),lamdan);
end
xnp1     = (1-alphan)*xn + alphan*PTn1(wn-lamdan*A1(yn,m),wn,yn,lamdan,m);
check    = rn;
changex  = rn;
sol1     = [iter,changex];
tic
while check > 1e-5
    xnm1    = xn;
    xn      = xnp1;
    lamdan  = lamdanp1;
    iter    = iter+1;
%     alphan  = 0.5*(1-1/(iter+1));
    wn      = xn + thetan*(xn - xnm1);
    pn      = wn - lamdan*A1(wn,m);
    yn      = Proj_Poly(pn,m,k);
    rn1     = A1(wn,m) - A1(yn,m);
    rn2     = wn - yn;
    if rn2 == 0; break; end
    if rn1 == 0
        lamdanp1 = lamdan;
    else
        lamdanp1 = min(miu*norm(rn2,2)/norm(rn1,2),lamdan);
    end
    xnp1     = (1-alphan)*xn + alphan*PTn1(wn-lamdan*A1(yn,m),wn,yn,lamdan,m);
    changex  = rn;
    check    = rn;
    sol1     = [sol1;[iter,changex]];
end
Time = toc;

disp(['iter = ',num2str(iter)]);
disp(['Time = ',num2str(Time)]);

figure
loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
xlabel('Number of iterations','FontSize',16,'interpreter','latex')
ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
I=legend('$||x_{n+1}-x_n||_2$');
set(I,'interpreter','latex');
box off
grid on

