function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_71_Fan(m)
clc;
k       = 10;
% m       = 100;
thetan  = 0.6;
x0      = ones(m,1);
x1      = rand(m,1);
iter     = 1;
alphan   = 0.1;
lamdan   = 1/(iter+1);
xnm1     = x0;
xn       = x1;
wn       = xn + thetan*(xn - xnm1);
pn       = wn - lamdan*A1(wn,m);
yn       = Proj_Poly(pn,m,k);
xnp1     = (1-alphan)*wn + alphan*PTn1(wn-lamdan*A1(yn,m),wn,yn,lamdan,m);
check    = norm(wn - yn,2);
changex  = norm(wn - yn,2);
sol1     = [iter,changex];
tic
while check > 1e-5
    xnm1     = xn;
    xn       = xnp1;
    iter     = iter+1;
    lamdan   = 1/(iter+1);
    wn       = xn + thetan*(xn - xnm1);
    pn       = wn - lamdan*A1(wn,m);
    yn       = Proj_Poly(pn,m,k);
    xnp1     = (1-alphan)*wn + alphan*PTn1(wn-lamdan*A1(yn,m),wn,yn,lamdan,m);
    changex  = norm(wn - yn,2);
    check    = norm(wn - yn,2);
    sol1     = [sol1;[iter,changex]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on
% 
