function y = A3(x,h)
t  = (0:h:1)';
z  = 0.*t;
y  = max(x,z);