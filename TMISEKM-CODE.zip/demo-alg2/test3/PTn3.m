function y = PTn3(x,a,b,h)
% a       = pn1 - yn;
% b       = innerp(a,yn);
innern  = innerp(a,x,h);
if innern <= b
    y = x;
else
    y = ((b-innern)/(norm(a,2))^2).*a + x;
end
