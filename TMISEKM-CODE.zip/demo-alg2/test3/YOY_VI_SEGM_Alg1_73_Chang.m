function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_73_Chang(x0,x1)
clc;
h        = 0.05;
t        = (0:h:1)';
lamda1   = 1.1;
alpha    = 0.343;
% delta    = 0.05;
% alpha    = 0.3;
delta    = 0.2;
n0       = 1000;
% x0      = 97*t.^2/12;
% x0       = (t.^2-exp(-t))./525;
% x1       = x0;
p1       = x1 - lamda1*A3(x1,h);
y1       = ProjC(p1,h);
iter     = 1;
lamdan   = lamda1;
xnm1     = x0;
xn       = x1;
yn       = y1;
miun     = 1 + 1/(1 + fix(iter/n0));
rn       = xnm1 - xn;
wn       = xn + delta*rn;
pn1      = wn - lamdan*A3(yn,h);
ynp1     = ProjC(pn1,h);
pn2      = wn - lamdan*A3(ynp1,h);
a        = pn1 - ynp1;
b        = innerp(a,ynp1,h);
xnp1     = PTn3(pn2,a,b,h);
rn1      = A3(ynp1,h) - A3(yn,h);
rn2      = ynp1 - yn;
if rn == 0
    lamdanp1 = lamdan*miun;
else
    lamdanp1 = min((alpha*norm(rn2,2))/norm(rn1,2),lamdan);
end
check    = norm(xnp1 - xn,2);
sol1     = [iter,check];
tic
while check > 1e-4
    xnm1     = xn;
    xn       = xnp1;
    yn       = ynp1;
    lamdan   = lamdanp1;
    iter     = iter + 1;
    miun     = 1 + 1/(1 + fix(iter/n0));
    rn       = xnm1 - xn;
    wn       = xn + delta*rn;
    pn1      = wn - lamdan*A3(yn,h);
    ynp1     = ProjC(pn1,h);
    pn2      = wn - lamdan*A3(ynp1,h);
    a        = pn1 - ynp1;
    b        = innerp(a,ynp1,h);
    xnp1     = PTn3(pn2,a,b,h);
    rn1      = A3(ynp1,h) - A3(yn,h);
    rn2      = ynp1 - yn;
    if rn == 0
        lamdanp1 = lamdan*miun;
    else
        lamdanp1 = min((alpha*norm(rn2,2))/norm(rn1,2),lamdan);
    end
    check    = norm(xnp1 - xn,2);
    sol1     = [sol1;[iter,check]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on
% 
