function [xnp1, iter, Time, sol1] = SEAP_Alg1_73(x0, x1, miu, lamda1)
% SEAP Algorithm 1 实现
% 输入:
%   x0        - 初始点 x_0
%   x1        - 初始点 x_1 (作为 x_{-1} 使用)
%   miu       - 参数 mu ∈ (0,1)
%   lamda1    - 初始步长 λ_{-1} > 0
% 输出:
%   xnp1      - 最终解 x_{k+1}
%   iter      - 迭代次数
%   Time      - 计算时间
%   sol1      - 迭代历史 [iter, check]

h = 0.05;  % 固定步长，与原有算法一致

% 参数设置
iter    = 0;
k       = 0;
lamdan  = lamda1;       % λ_{-1}
xn      = x0;            % x_k = x_0
xnm1    = x1;            % x_{k-1} = x_1 (即 x_{-1})
ynm1    = zeros(size(x0));            % y_{-1} = x_1

% beta_k 函数: beta_k = 1/(k+1)^2 (保证级数收敛)
betak_func = @(k) 1/((k+1)^2);

% alpha_k 函数: alpha_k = 1/(k+1)
alphak_func = @(k) 1/(k+1);

% 初始收敛检查
check   = inf;
sol1    = [];

tic;
while check > 1e-4
    
    % ========== Step 2: 计算 y_k ==========
    % y_k = P_C( x_k + (k-1)/(k+2)*(x_k - x_{k-1}) + (k+1)/(k+2)*(x_k - y_{k-1}) - λ_{k-1}*F(y_{k-1}) )
    
    if k == 0
        % k=0 时: (k-1)/(k+2) = -1/2, (k+1)/(k+2) = 1/2
        coef1 = -1/2;
        coef2 = 1/2;
    else
        coef1 = (k-1)/(k+2);
        coef2 = (k+1)/(k+2);
    end
    
    % 计算投影前的点
    temp = xn + coef1*(xn - xnm1) + coef2*(xn - ynm1) - lamdan*A3(ynm1, h);
    yn   = ProjC(temp, h);
    
    % ========== Step 3: 更新步长 λ_k 和计算 u_k ==========
    
    % 计算 F(y_k) 和 F(y_{k-1})
    Fyn   = A3(yn, h);
    Fynm1 = A3(ynm1, h);
    
    % 计算范数
    diff_y = yn - ynm1;
    norm_diff_y = norm(diff_y, 2);
    norm_diff_Fy = norm(Fyn - Fynm1, 2);
    
    % 更新 λ_k
    beta_k = betak_func(k);
    threshold = miu * norm_diff_y / lamdan;
    
    if norm_diff_Fy > threshold && norm_diff_Fy > 0
        lamdanp1 = miu * norm_diff_y / (2 * norm_diff_Fy);
    else
        lamdanp1 = (1 + beta_k) * lamdan;
    end
    
    % 计算 alpha_k 和 u_k
    alpha_k = alphak_func(k);
    uk = alpha_k * x0 + (1 - alpha_k) * xn;
    
    % ========== Step 4: 构造半空间 T_k 并更新 x_{k+1} ==========
    
    % 构造半空间 T_k 的参数
    % T_k = {w : <u_k - λ_k(1-α_k)F(y_{k-1}) - y_k, w - y_k> <= 0}
    a = uk - lamdan*(1 - alpha_k)*Fynm1 - yn;
    b = innerp(a, yn, h);  % <a, y_k>
    
    % 计算投影前的点: u_k - λ_k(1-α_k)F(y_k)
    pn = uk - lamdan*(1 - alpha_k)*Fyn;
    
    % 投影到半空间 T_k
    xnp1 = PTn3(pn, a, b, h);
    
    % 收敛检查
    check = norm(xnp1 - xn, 2);
    iter  = iter + 1;
    sol1  = [sol1; [iter, check]];
    
    % 更新变量为下一次迭代
    xnm1  = xn;
    xn    = xnp1;
    ynm1  = yn;
    lamdan = lamdanp1;
    k     = k + 1;
    
    % 防止无限循环
    if iter > 2000
        warning('达到最大迭代次数');
        break;
    end
end
Time = toc;

end


