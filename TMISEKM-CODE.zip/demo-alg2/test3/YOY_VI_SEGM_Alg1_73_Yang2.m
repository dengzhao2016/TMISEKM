function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_73_Yang2(x1,miu,lamda1)
clc;
h       = 0.05;
t       = (0:h:1)';
% lamda1  = 1.1;
% miu     = 0.05;
% x1      = (97*t.^2+4*t)/12;
iter    = 1;
alphan  = 1/(20*(iter + 2));
lamdan  = lamda1;
xn      = x1;
pn1     = xn - lamdan*A3(xn,h);
yn      = ProjC(pn1,h);
pn2     = xn - lamdan*A3(yn,h);
a       = pn1 - yn;
b       = innerp(a,yn,h);
zn      = PTn3(pn2,a,b,h);
xnp1    = alphan*x1 + (1 - alphan)*zn;
rn1     = A3(xn,h) - A3(yn,h);
rn2     = xn - yn;
rn3     = zn - yn;
rn      = dot(rn1,rn3);
if rn > 0
    lamdanp1 = min(miu*(norm(rn2,2)^2+norm(rn3,2)^2)/(2*rn),lamdan);
else
    lamdanp1 = lamdan;
end
check    = norm(xnp1 - xn,2);
sol1     = [iter,check];
tic
while check > 1e-4
    xn      = xnp1;
    lamdan  = lamdanp1;
    iter    = iter + 1;
    alphan  = 1/(20*(iter + 2));
    pn1     = xn - lamdan*A3(xn,h);
    yn      = ProjC(pn1,h);
    pn2     = xn - lamdan*A3(yn,h);
    a       = pn1 - yn;
    b       = innerp(a,yn,h);
    zn      = PTn3(pn2,a,b,h);
    xnp1    = alphan*x1 + (1 - alphan)*zn;
    rn1     = A3(xn,h) - A3(yn,h);
    rn2     = xn - yn;
    rn3     = zn - yn;
    rn      = dot(rn1,rn3);
    if rn > 0
        lamdanp1 = min(miu*(norm(rn2,2)^2+norm(rn3,2)^2)/(2*rn),lamdan);
    else
        lamdanp1 = lamdan;
    end
    check    = norm(xnp1 - xn,2);
    sol1     = [sol1;[iter,check]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on
% 
