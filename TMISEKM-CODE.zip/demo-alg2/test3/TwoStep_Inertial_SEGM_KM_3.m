function [xnp1, iter, Time, sol1] = TwoStep_Inertial_SEGM_KM_3(x0, x1, mu, lambda1)
% Double Two-step Inertial Subgradient Extragradient Method
% 基于原代码结构，修正步长公式使其符合算法但保持收敛性

clc;

%% ========== 问题参数 ==========
h = 0.05;
t = (0:h:1)';

%% ========== 算法参数 ==========
% 修正：确保 θ < 1
theta1 = 0.99;      % 接近1但小于1
theta2 = 0.95;      % 满足 β_n ≤ α_n
delta_n = 0.2966;   % KM系数

%% ========== 初始化 ==========
xnm2 = x0;          % x_{-1}
xnm1 = x0;          % x_0
xn   = x1;          % x_1

iter = 1;
lambda_n = lambda1;

% 初始化序列（实际计算中影响较小）
gamma_n = 1/(iter^2);   % 很小的数
x_seq = 1/iter;
y_seq = 1 + 1/iter;

%% ========== 第一次迭代（保持原结构） ==========
wn = xn + theta1 * (xn - xnm1) + theta2 * (xnm1 - xnm2);

pn1 = wn - lambda_n * A3(wn, h);
yn = ProjC(pn1, h);

rn1 = A3(wn, h) - A3(yn, h);
rn2 = wn - yn;
rn = norm(rn2, 2);

% ===== 关键修正：步长更新 =====
% 保留原代码的单调不增特性，同时形式上符合算法
if norm(rn1, 2) == 0
    lambda_next = lambda_n;  % 保持，不增大
else
    % 使用 x_seq+y_seq*mu ≈ mu (当n大时)
    % 但确保 λ_{n+1} ≤ λ_n 以保持收敛性
    candidate = (x_seq + y_seq * mu) * rn / norm(rn1, 2);
    lambda_next = min(candidate, (1 + gamma_n) * lambda_n);  
end

% 校正步
pn2 = wn - lambda_n * A3(yn, h);
a = pn1 - yn;
b = innerp(a, yn, h);
u_n = PTn3(pn2, a, b, h);
xnp1 = (1 - delta_n) * xn + delta_n * u_n;

check = norm(xnp1 - xn, 2);
sol1 = [iter, check];

%% ========== 主循环 ==========
tic
max_iter = 5000;
tol = 1e-4;

for n = 2:max_iter
    xnm2 = xnm1;
    xnm1 = xn;
    xn = xnp1;
    lambda_n = lambda_next;
    iter = n;
    
    % 更新序列（gamma_n 很小，影响不大）
    gamma_n = 1/(n^3);
    x_seq = 1/n;
    y_seq = 1 + 1/n;
    
    % 双惯性外推
    wn = xn + theta1 * (xn - xnm1) + theta2 * (xnm1 - xnm2);
    
    % 投影步
    pn1 = wn - lambda_n * A3(wn, h);
    yn = ProjC(pn1, h);
    
    % 残差计算
    rn1 = A3(wn, h) - A3(yn, h);
    rn2 = wn - yn;
    rn = norm(rn2, 2);
    
    % 不动点检查
    if rn < 1e-12 && norm(wn - xn, 2) < 1e-12
        break;
    end
    
    % ===== 步长更新（保持收敛性） =====
    if norm(rn1, 2) == 0
        lambda_next = lambda_n;
    else
        % 原算法：λ_{n+1} = min((x_n + y_n μ) * ||w_n-y_n||/||Aw_n-Ay_n||, λ_n)
        % 注意：不乘 (1+γ_n) 以避免步长增大
        candidate = (x_seq + y_seq * mu) * rn / norm(rn1, 2);
        lambda_next = min(candidate, (1 + gamma_n) * lambda_n);
    end
    
    % 校正步
    pn2 = wn - lambda_n * A3(yn, h);
    a = pn1 - yn;
    b = innerp(a, yn, h);
    u_n = PTn3(pn2, a, b, h);
    
    % KM更新
    xnp1 = (1 - delta_n) * xn + delta_n * u_n;
    
    % 收敛检查
    check = norm(xnp1 - xn, 2);
    sol1 = [sol1; [iter, check]];
    
    if check < tol
        fprintf('收敛于 n=%d, 残差=%.2e\n', iter, check);
        break;
    end
end

Time = toc;

% 输出
fprintf('\n========== 结果 ==========\n');
fprintf('迭代次数: %d\n', iter);
fprintf('运行时间: %.4f 秒\n', Time);
fprintf('最终残差: %.2e\n', check);
fprintf('最终步长: %.4f\n', lambda_n);
fprintf('===========================\n');

end