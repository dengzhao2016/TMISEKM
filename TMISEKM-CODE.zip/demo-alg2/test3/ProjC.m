function y = ProjC(x,h)
t  = (0:h:1)';
w1 = t.*x;
w2 = trapz(t,w1)-2;
w3 = t.^2;
w4 = trapz(t,w3);
w5 = (w2/w4).*t;
y  = x - w5;

