function y =innerp(a,b,h)
t = (0:h:1)';
w = a.*b;
y = trapz(t,w);