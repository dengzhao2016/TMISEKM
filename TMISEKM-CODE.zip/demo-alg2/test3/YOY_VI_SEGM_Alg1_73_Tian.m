function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_73_Tian
clc;
h       = 0.05;
t       = (0:h:1)';
lamda1  = 1.1;
thetan  = 0.25;
miu     = 0.1;
x0      = (97*t.^2+4*t)/12;
x1      = (t.^2-exp(-t))./525;
iter    = 1;
alphan  = 0.2;
lamdan  = lamda1;
xnm1    = x0;
xn      = x1;
wn      = xn + thetan*(xn - xnm1);
pn1     = wn - lamdan*A3(wn,h);
yn      = ProjC(pn1,h);
rn1     = A3(wn,h)-A3(yn,h);
rn2     = wn - yn;
rn      = norm(rn2,2);
if rn1 == 0
    lamdanp1 = lamdan;
else
    lamdanp1 = min(miu*rn/norm(rn1,2),lamdan);
end
pn2      = wn - lamdan*A3(yn,h);
a        = pn1 - yn;
b        = innerp(a,yn,h);
xnp1     = (1-alphan)*xn + alphan*PTn3(pn2,a,b,h);
check    = norm(xnp1 - xn,2);
sol1     = [iter,check];
tic
while check > 1e-4
    xnm1    = xn;
    xn      = xnp1;
    lamdan  = lamdanp1;
    iter    = iter+1;
    wn      = xn + thetan*(xn - xnm1);
    pn1     = wn - lamdan*A3(wn,h);
    yn      = ProjC(pn1,h);
    rn1     = A3(wn,h) - A3(yn,h);
    rn2     = wn - yn;
    if rn2 == 0; break; end
    if rn1 == 0
        lamdanp1 = lamdan;
    else
        lamdanp1 = min(miu*norm(rn2,2)/norm(rn1,2),lamdan);
    end
    pn2      = wn - lamdan*A3(yn,h);
    a        = pn1 - yn;
    b        = innerp(a,yn,h);
    xnp1     = (1-alphan)*xn + alphan*PTn3(pn2,a,b,h);
    check    = norm(xnp1 - xn,2);
    sol1     = [sol1;[iter,check]];
end
Time = toc;

disp(['iter = ',num2str(iter)]);
disp(['Time = ',num2str(Time)]);

figure
loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
xlabel('Number of iterations','FontSize',16,'interpreter','latex')
ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
I=legend('$||x_{n+1}-x_n||_2$');
set(I,'interpreter','latex');
box off
grid on

