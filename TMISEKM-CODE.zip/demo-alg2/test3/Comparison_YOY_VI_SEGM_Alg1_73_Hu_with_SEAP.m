function Comparison_YOY_VI_SEGM_Alg1_73_Hu_with_SEAP
clc
miu     = 0.99;
lamda1  = 1.1;
h       = 0.05;
t       = (0:h:1)';
lamda11 = 1e-3;
miu1 = 1e-8;

% % Case I
%x0  = (t.^2-exp(-7*t))./250;
%x1  = (sin(3*t) + cos(10*t))/100;

% Case II
x0  = (sin(3*t) + cos(10*t))/100;
x1  = (97*t.^2 + 4*t)/13;

% 运行所有算法
[xnp1_YOY, iter_YOY, Time_YOY, sol_YOY] = YOY_VI_SEGM_Alg1_73(x0,x1,miu,lamda1);
[xnp1_YNS, iter_YNS, Time_YNS, sol_YNS] = YOY_VI_SEGM_Alg1_73_YNS(x0,x1,miu,lamda1);
[xnp1_Thong, iter_Thong, Time_Thong, sol_Thong] = YOY_VI_SEGM_Alg1_73_Thong(x0,x1,miu,lamda1);
[xnp1_Fan, iter_Fan, Time_Fan, sol_Fan] = YOY_VI_SEGM_Alg1_73_Fan(x0,x1);
% [xnp1_Yang, iter_Yang, Time_Yang, sol_Yang] = YOY_VI_SEGM_Alg1_73_Yang(x1,miu,lamda1);
[xnp1_Yang2, iter_Yang2, Time_Yang2, sol_Yang2] = YOY_VI_SEGM_Alg1_73_Yang2(x1,miu,lamda1);
% [xnp1_Chang, iter_Chang, Time_Chang, sol_Chang] = YOY_VI_SEGM_Alg1_73_Chang(x0,x1);
[xnp1_Hu, iter_Hu, Time_Hu, sol_Hu] = TwoStep_Inertial_SEGM_KM_3(x0,x1,miu,lamda1);  % Hu算法

% ========== 新增: SEAP 算法 ==========
[xnp1_SEAP, iter_SEAP, Time_SEAP, sol_SEAP] = SEAP_Alg1_73(x0, x1, miu1, lamda11);

% 显示计算时间
disp('========== 计算时间比较 ==========');
disp(['Time_YOY    = ', num2str(Time_YOY), ' 秒']);
disp(['Time_YNS    = ', num2str(Time_YNS), ' 秒']);
disp(['Time_Thong  = ', num2str(Time_Thong), ' 秒']);
disp(['Time_Fan    = ', num2str(Time_Fan), ' 秒']);
% disp(['Time_Yang   = ', num2str(Time_Yang), ' 秒']);
disp(['Time_Yang2  = ', num2str(Time_Yang2), ' 秒']);
% disp(['Time_Chang  = ', num2str(Time_Chang), ' 秒']);
disp(['Time_Hu     = ', num2str(Time_Hu), ' 秒']);
disp(['Time_SEAP   = ', num2str(Time_SEAP), ' 秒']);  % 新增

% 显示迭代次数
disp('========== 迭代次数比较 ==========');
disp(['iter_YOY    = ', num2str(iter_YOY)]);
disp(['iter_YNS    = ', num2str(iter_YNS)]);
disp(['iter_Thong  = ', num2str(iter_Thong)]);
disp(['iter_Fan    = ', num2str(iter_Fan)]);
% disp(['iter_Yang   = ', num2str(iter_Yang)]);
disp(['iter_Yang2  = ', num2str(iter_Yang2)]);
% disp(['iter_Chang  = ', num2str(iter_Chang)]);
disp(['iter_Hu     = ', num2str(iter_Hu)]);
disp(['iter_SEAP   = ', num2str(iter_SEAP)]);  % 新增

% 绘图对比 - 包含 SEAP 算法
figure;
% 先画你的算法 Two-Step-ISEKM（让它出现在图例第一位）
loglog(sol_Hu(:,1), sol_Hu(:,2), '-rh', 'LineWidth', 2, 'MarkerSize', 7); hold on;
% 再画其他算法
loglog(sol_YOY(:,1), sol_YOY(:,2), '-c*', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_YNS(:,1), sol_YNS(:,2), '--b*', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Thong(:,1), sol_Thong(:,2), '-gs', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Fan(:,1), sol_Fan(:,2), '-kp', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Yang2(:,1), sol_Yang2(:,2), '-yo', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_SEAP(:,1), sol_SEAP(:,2), '-md', 'LineWidth', 2, 'MarkerSize', 7);
hold off;

xlabel('Number of iterations', 'FontSize', 16, 'interpreter', 'latex')
ylabel('$||e_n||_2$', 'FontSize', 16, 'interpreter', 'latex')

% 图例顺序与绘图顺序一致：Two-Step-ISEKM 放在第一个
I = legend('Two-Step-ISEKM', 'YOY Alg', 'Shehu Alg.', 'Thong Alg.', ...
           'Fan Alg.', 'Yang2 Alg.', 'Adamu  Alg.');
set(I, 'interpreter', 'latex', 'Location', 'northeast');
box off
grid on
end