function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_72_Chang(m,k,M)
clc;
% k        = 30;
% m        = 20;
lamda1   = 0.1;
% alpha    = 0.343;
% delta    = 0.05;
alpha    = 0.3;
delta    = 0.2;
n0       = 1000;
%B       = rand(m,m);
%S       = rand(m,m);
%Sskew   = 0.5*S - 0.5*S';
%D       = diag(rand(1,m));
%M       = B*B' + Sskew + D;
% L       = norm(M,2); % Lipschitz constant
x0       = rand(m,1);
x1       = x0;
p1       = x1 - lamda1*A2(x1,m,M);
y1       = Proj_Poly(p1,m,k);
iter     = 1;
lamdan   = lamda1;
xnm1     = x0;
xn       = x1;
yn       = y1;
miun     = 1 + 1/(1 + fix(iter/n0));
rn       = xnm1 - xn;
wn       = xn + delta*rn;
pn       = wn - lamdan*A2(yn,m,M);
ynp1     = Proj_Poly(pn,m,k);
xnp1     = PTn2(wn - lamdan*A2(ynp1,m,M),wn,ynp1,lamdan,m,M);
rn1      = A2(ynp1,m,M) - A2(yn,m,M);
rn2      = ynp1 - yn;
if rn == 0
    lamdanp1 = lamdan*miun;
else
    lamdanp1 = min((alpha*norm(rn2,2))/norm(rn1,2),lamdan);
end
% check    = norm(xnp1-xn,2);
% changex  = norm(xnp1-xn,2);
check    = norm(xn,2);
changex  = norm(xn,2);
sol1     = [iter,changex];
tic
while check > 1e-3
    xnm1     = xn;
    xn       = xnp1;
    yn       = ynp1;
    lamdan   = lamdanp1;
    iter     = iter+1;
    miun     = 1 + 1/(1 + fix(iter/n0));
    rn       = xnm1 - xn;
    wn       = xn + delta*rn;
    pn       = wn - lamdan*A2(yn,m,M);
    ynp1     = Proj_Poly(pn,m,k);
    xnp1     = PTn2(wn - lamdan*A2(ynp1,m,M),wn,ynp1,lamdan,m,M);
    rn1      = A2(ynp1,m,M) - A2(yn,m,M);
    rn2      = ynp1 - yn;
    if rn == 0
        lamdanp1 = lamdan*miun;
    else
        lamdanp1 = min((alpha*norm(rn2,2))/norm(rn1,2),lamdan);
    end
    changex  = norm(xn,2);
    check    = norm(xn,2);
    sol1     = [sol1;[iter,changex]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on

