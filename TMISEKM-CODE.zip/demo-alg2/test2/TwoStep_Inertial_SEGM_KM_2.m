function [xnp1, iter, Time, sol1] = TwoStep_Inertial_SEGM_KM_2(m, k, M)
% Double Two-step Inertial Subgradient Extragradient Method with Adaptive Step Size
% 对应论文中的 Algorithm: Double Two-step Inertial Subgradient Extragradient Method
% (m, k) - 维度和投影边界

clc;

%% ========== 参数设置 ==========
% 算法参数 (满足假设条件)
mu      = 0.9;          % mu in (0,1)
lambda1 = 0.1;          % 初始步长 lambda_1 > 0
theta1  = 0.99;         % theta_n^1, in [0,1/2)
theta2  = 0.9;          % theta_n^2, in [0,1/2)
a_n     = 0.2966;          

%% ========== 问题设定 ==========
%B       = rand(m, m);
%S       = rand(m, m);
%5Sskew   = 0.5*S - 0.5*S';
%D       = diag(rand(1, m));
%M       = B*B' + Sskew + D;

%% ========== 初始化 ==========
x0      = rand(m, 1);
x1      = rand(m, 1);
xnm2    = x0;            % x_{-1} = x0
xnm1    = x0;            % x_{0} = x0
xn      = x1;            % x_{1} = x1

iter     = 1;
lambda_n = lambda1;

% 初始化序列 {gamma_n}, {x_seq}, {y_seq} 满足收敛条件
gamma_n  = 1/(iter^2);   % gamma_n 满足 sum < infinity (p=2>1)
x_seq    = 1/iter;       % x_n -> 0
y_seq    = 1 + 1/iter;   % y_n -> 1

% 双惯性外推: w_n = x_n + theta1*(x_n - x_{n-1}) + theta2*(x_{n-1} - x_{n-2})
w_n = xn + theta1 * (xn - xnm1) + theta2 * (xnm1 - xnm2);

% 投影步: y_n = P_C(w_n - lambda_n * A w_n)
p_n = w_n - lambda_n * A2(w_n, m, M);
y_n = Proj_Poly(p_n, m, k);

% 计算残差
Aw = A2(w_n, m, M);
Ay = A2(y_n, m, M);
rn1 = Aw - Ay;
rn2 = w_n - y_n;
rn  = norm(rn2, 2);

% 停止条件检查: w_n = y_n = x_n
if rn < 1e-12 && norm(w_n - xn, 2) < 1e-12
    fprintf('算法在 n=%d 处终止: w_n = y_n = x_n\n', iter);
    xnp1 = xn;
    Time = 0;
    sol1 = [iter, rn];
    return;
end

% 自适应步长更新 (lambda_{n+1})
if norm(rn1, 2) == 0
    lambda_next = (1 + gamma_n) * lambda_n;
else
    lambda_next = min((x_seq + y_seq * mu) * rn / norm(rn1, 2), (1 + gamma_n) * lambda_n);
end

% 校正步: u_n = P_{T_n}(w_n - lambda_n * A y_n)
% 然后 x_{n+1} = (1 - a_n) * x_n + a_n * u_n
u_n  = PTn2(w_n - lambda_n * Ay, w_n, y_n, lambda_n, m, M);
xnp1 = (1 - a_n) * xn + a_n * u_n;

% 记录收敛历史
changex = norm(xn, 2);
sol1    = [iter, changex];

%% ========== 主迭代循环 ==========
tic
max_iter = 10000;        % 最大迭代次数
tol      = 1e-3;        % 容差

for n = 2:max_iter
    % 更新历史点
    xnm2    = xnm1;     % x_{n-2} <- x_{n-1}
    xnm1    = xn;       % x_{n-1} <- x_n
    xn      = xnp1;     % x_n <- x_{n+1}
    
    lambda_n = lambda_next;
    iter     = n;
    
    % 更新序列 (满足收敛条件)
    gamma_n  = 1/(n^1.5);        % gamma_n 满足 sum < infinity
    x_seq    = 1/n;              % x_n -> 0
    y_seq    = 1 + 1/n;          % y_n -> 1
    
    % 双惯性外推: w_n = x_n + theta1*(x_n - x_{n-1}) + theta2*(x_{n-1} - x_{n-2})
    w_n = xn + theta1 * (xn - xnm1) + theta2 * (xnm1 - xnm2);
    
    % 投影步: y_n = P_C(w_n - lambda_n * A w_n)
    p_n = w_n - lambda_n * A2(w_n, m, M);
    y_n = Proj_Poly(p_n, m, k);
    
    % 计算残差
    Aw = A2(w_n, m, M);
    Ay = A2(y_n, m, M);
    rn1 = Aw - Ay;
    rn2 = w_n - y_n;
    rn  = norm(rn2, 2);
    
    % 停止条件: w_n = y_n = x_n
    if rn < 1e-10 && norm(w_n - xn, 2) < 1e-10
        fprintf('算法在 n=%d 处终止: w_n = y_n = x_n, 残差 = %.2e\n', iter, rn);
        break;
    end
    
    % 自适应步长更新 (lambda_{n+1})
    if norm(rn1, 2) == 0
        lambda_next = (1 + gamma_n) * lambda_n;
    else
        lambda_next = min((x_seq + y_seq * mu) * rn / norm(rn1, 2), (1 + gamma_n) * lambda_n);
    end
    
    % 校正步: u_n = P_{T_n}(w_n - lambda_n * A y_n)
    u_n  = PTn2(w_n - lambda_n * Ay, w_n, y_n, lambda_n, m, M);
    
    % 更新 x_{n+1} = (1 - a_n) * x_n + a_n * u_n
    xnp1 = (1 - a_n) * xn + a_n * u_n;
    
    % 收敛监测
    changex = norm(xn, 2);
    sol1    = [sol1; [iter, changex]];
    
    % 提前终止条件
    if changex < tol
        fprintf('算法在 n=%d 处收敛, ||x_n||_2 = %.2e\n', iter, changex);
        break;
    end
end

Time = toc;

fprintf('\n========== 算法终止信息 ==========\n');
fprintf('迭代次数: %d\n', iter);
fprintf('最终残差: %.2e\n', changex);
fprintf('运行时间: %.4f 秒\n', Time);
fprintf('最终步长: %.4f\n', lambda_n);
fprintf('==================================\n');

% 可选：绘制收敛图
% figure;
% loglog(sol1(:,1), sol1(:,2), '-r*', 'LineWidth', 2, 'MarkerSize', 7);
% xlabel('Number of iterations', 'FontSize', 16, 'interpreter', 'latex');
% ylabel('$||x_n||_2$', 'FontSize', 16, 'interpreter', 'latex');
% grid on;

end