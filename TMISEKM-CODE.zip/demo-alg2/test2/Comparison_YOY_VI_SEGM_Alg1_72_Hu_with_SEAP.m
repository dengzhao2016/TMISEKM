function Comparison_YOY_VI_SEGM_Alg1_72_Hu_with_SEAP
clc
m = 10;
k = 20;

% 生成一次 B, S, M
B = rand(m, m);
S = rand(m, m);
Sskew = 0.5*S - 0.5*S';
D = diag(rand(1, m));
M = B*B' + Sskew + D;

% ========== 新增: SEAP 算法 ==========
[xnp1_SEAP, iter_SEAP, Time_SEAP, sol_SEAP] = SEAP_Alg1_72(m,k,M);
% 运行所有算法
[xnp1_YOY, iter_YOY, Time_YOY, sol_YOY] = YOY_VI_SEGM_Alg1_72(m,k,M);
[xnp1_YNS, iter_YNS, Time_YNS, sol_YNS] = YOY_VI_SEGM_Alg1_72_YNS(m,k,M);
[xnp1_Thong, iter_Thong, Time_Thong, sol_Thong] = YOY_VI_SEGM_Alg1_72_Thong(m,k,M);
[xnp1_Yang, iter_Yang, Time_Yang, sol_Yang] = YOY_VI_SEGM_Alg1_72_Yang(m,k,M);
[xnp1_Yang2, iter_Yang2, Time_Yang2, sol_Yang2] = YOY_VI_SEGM_Alg1_72_Yang2(m,k,M);
[xnp1_Chang, iter_Chang, Time_Chang, sol_Chang] = YOY_VI_SEGM_Alg1_72_Chang(m,k,M);
[xnp1_New, iter_New, Time_New, sol_New] = TwoStep_Inertial_SEGM_KM_2(m,k,M);


% 显示计算时间
disp('========== 计算时间比较 ==========');
disp(['Time_YOY    = ', num2str(Time_YOY), ' 秒']);
disp(['Time_YNS    = ', num2str(Time_YNS), ' 秒']);
disp(['Time_Thong  = ', num2str(Time_Thong), ' 秒']);
disp(['Time_Yang   = ', num2str(Time_Yang), ' 秒']);
disp(['Time_Yang2  = ', num2str(Time_Yang2), ' 秒']);
disp(['Time_Chang  = ', num2str(Time_Chang), ' 秒']);
disp(['Time_New    = ', num2str(Time_New), ' 秒']);
disp(['Time_SEAP   = ', num2str(Time_SEAP), ' 秒']);  % 新增

% 显示迭代次数
disp('========== 迭代次数比较 ==========');
disp(['iter_YOY    = ', num2str(iter_YOY)]);
disp(['iter_YNS    = ', num2str(iter_YNS)]);
disp(['iter_Thong  = ', num2str(iter_Thong)]);
disp(['iter_Yang   = ', num2str(iter_Yang)]);
disp(['iter_Yang2  = ', num2str(iter_Yang2)]);
disp(['iter_Chang  = ', num2str(iter_Chang)]);
disp(['iter_New    = ', num2str(iter_New)]);
disp(['iter_SEAP   = ', num2str(iter_SEAP)]);  % 新增

% 绘图对比 - 包含 SEAP 算法
figure;
loglog(sol_YOY(:,1), sol_YOY(:,2), '-c*', 'LineWidth', 2, 'MarkerSize', 7); hold on;
loglog(sol_YNS(:,1), sol_YNS(:,2), '--b*', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Thong(:,1), sol_Thong(:,2), '-gs', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Yang(:,1), sol_Yang(:,2), '-kp', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Yang2(:,1), sol_Yang2(:,2), '-yo', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_Chang(:,1), sol_Chang(:,2), '-rh', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_New(:,1), sol_New(:,2), '-m^', 'LineWidth', 2, 'MarkerSize', 7);
loglog(sol_SEAP(:,1), sol_SEAP(:,2), '-bd', 'LineWidth', 2, 'MarkerSize', 7);  % SEAP - 蓝色菱形
hold off;

xlabel('Number of iterations', 'FontSize', 16, 'interpreter', 'latex')
ylabel('$||e_n||_2$', 'FontSize', 16, 'interpreter', 'latex')
I = legend('YOY Alg.', 'YNS Alg.', 'Thong Alg.', 'Yang Alg.', ...
           'Yang2 Alg.', 'Chang Alg.', 'New Alg.', 'SEAP Alg.');
set(I, 'interpreter', 'latex', 'Location', 'northeast');
box off
grid on

end