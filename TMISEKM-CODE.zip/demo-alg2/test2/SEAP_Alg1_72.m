function [xnp1, iter, Time, sol1] = SEAP_Alg1_72(m, k, M)
% SEAP Algorithm 1 - 有限维版本 (m,k)
% 输入:
%   m  - 问题维度
%   k  - 多面体约束参数 (用于 Proj_Poly)
%   M  - 矩阵 (算子 F(x) = M*x)
% 输出:
%   xnp1  - 最终解
%   iter  - 迭代次数
%   Time  - 计算时间
%   sol1  - 迭代历史 [iter, changex]

clc;

% 参数设置 (与 YOY 算法一致的风格)
lamda1  = 0.1;          % λ_{-1} > 0
miu     = 0.99;         % μ ∈ (0,1)
x0      = rand(m,1);    % 初始点 x_0
x1      = rand(m,1);    % 初始点 x_1 (作为 x_{-1})

% beta_k 和 alpha_k 的参数
% beta_k = 1/(k+1)^2, alpha_k = 1/(k+1)
% 这里用迭代计数器 kk 来定义

iter    = 0;            % 迭代计数器 (对应算法中的 k)
kk      = 0;            % 算法步数 k
lamdan  = lamda1;       % λ_{-1}
xn      = x0;           % x_k = x_0
xnm1    = x1;           % x_{k-1} = x_1
ynm1    = zeros(m,1);   % y_{-1} = 0

% 初始收敛检查 (仿照 YOY 风格)
check    = norm(xn, 2);
changex  = norm(xn, 2);
sol1     = [iter+1, changex];

tic;
while check > 1e-3
    
    % ========== Step 2: 计算 y_k ==========
    % y_k = P_C( x_k + (k-1)/(k+2)*(x_k - x_{k-1}) + (k+1)/(k+2)*(x_k - y_{k-1}) - λ_{k-1}*F(y_{k-1}) )
    
    if kk == 0
        coef1 = -1/2;   % (0-1)/(0+2)
        coef2 = 1/2;    % (0+1)/(0+2)
    else
        coef1 = (kk-1)/(kk+2);
        coef2 = (kk+1)/(kk+2);
    end
    
    % 计算投影前的点
    temp = xn + coef1*(xn - xnm1) + coef2*(xn - ynm1) - lamdan*A2(ynm1, m, M);
    yn   = Proj_Poly(temp, m, k);
    
    % ========== Step 3: 更新步长 λ_k 和计算 u_k ==========
    
    % 计算 F(y_k) 和 F(y_{k-1})
    Fyn   = A2(yn, m, M);
    Fynm1 = A2(ynm1, m, M);
    
    % 计算范数
    diff_y = yn - ynm1;
    norm_diff_y = norm(diff_y, 2);
    norm_diff_Fy = norm(Fyn - Fynm1, 2);
    
    % 更新 λ_k (公式 11)
    beta_k = 1/((kk+1)^2);          % β_k = 1/(k+1)^2
    threshold = miu * norm_diff_y / lamdan;
    
    if norm_diff_Fy > threshold && norm_diff_Fy > 0
        lamdanp1 = miu * norm_diff_y / (2 * norm_diff_Fy);
    else
        lamdanp1 = (1 + beta_k) * lamdan;
    end
    
    % 计算 alpha_k 和 u_k (公式 12)
    alpha_k = 1/(kk+1);             % α_k = 1/(k+1)
    uk = alpha_k * x0 + (1 - alpha_k) * xn;
    
    % ========== Step 4: 构造半空间 T_k 并更新 x_{k+1} (公式 13) ==========
    
    % 构造半空间 T_k 的参数
    % T_k = {w : <u_k - λ_k(1-α_k)F(y_{k-1}) - y_k, w - y_k> <= 0}
    a_vec = uk - lamdan*(1 - alpha_k)*Fynm1 - yn;
    b_val = dot(a_vec, yn);         % <a, y_k>
    
    % 计算投影前的点: u_k - λ_k(1-α_k)F(y_k)
    pn = uk - lamdan*(1 - alpha_k)*Fyn;
    
    % 投影到半空间 T_k
    xnp1 = PTn3_SEAP(pn, a_vec, b_val);
    
    % 收敛检查 (仿照 YOY 风格)
    changex = norm(xn, 2);
    check   = norm(xn, 2);
    iter    = iter + 1;
    sol1    = [sol1; [iter+1, changex]];
    
    % 更新变量为下一次迭代
    xnm1   = xn;
    xn     = xnp1;
    ynm1   = yn;
    lamdan = lamdanp1;
    kk     = kk + 1;
    
    % 防止无限循环
    if iter > 1000
        warning('SEAP: 达到最大迭代次数');
        break;
    end
end
Time = toc;

end

