function y = PTn3_SEAP(x, a, b)
% 投影到半空间 T_k
% a: 法向量
% b: <a, y_k> (边界值)
innern = dot(a, x);
if innern <= b
    y = x;
else
    y = x + (b - innern) .* a / (norm(a, 2)^2);
end
end