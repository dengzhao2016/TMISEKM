function y = PTn2(x,h1,h2,h3,m,M)
% h1 = wn; h2 = yn; h3 = lamdan
a      = h1 - h2 - h3*A2(h1,m,M);
b      = dot(a,h2);
innern = dot(a,x);
if innern > b
    y = x + (b - innern).*a/(norm(a,2).^2);
else
    y = x;
end