function y = A2(x,m,M)
q     = zeros(m,1);
y     = M*x + q;