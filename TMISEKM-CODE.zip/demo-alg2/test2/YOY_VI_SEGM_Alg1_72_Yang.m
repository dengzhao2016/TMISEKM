function [xnp1,iter,Time,sol1] = YOY_VI_SEGM_Alg1_72_Yang(m,k,M)
clc;
% k       = 30;
% m       = 20;
lamda1  = 0.1;
miu     = 0.1;
%B       = rand(m,m);
%S       = rand(m,m);
%Sskew   = 0.5*S - 0.5*S';
%D       = diag(rand(1,m));
%M       = B*B' + Sskew + D;
% L      = norm(M,2); % Lipschitz constant
x1      = rand(m,1);
iter    = 1;
lamdan  = lamda1;
xn      = x1;
pn      = xn-lamdan*A2(xn,m,M);
yn      = Proj_Poly(pn,m,k);
xnp1    = PTn2(xn - lamdan*A2(yn,m,M),xn,yn,lamdan,m,M);
rn1     = A2(xn,m,M) - A2(yn,m,M);
rn2     = xn - yn;
rn3     = xnp1 - yn;
rn      = dot(rn1,rn3);
if rn > 0
    lamdanp1 = min(miu*(norm(rn2,2)^2+norm(rn3,2)^2)/(2*rn),lamdan);
else
    lamdanp1 = lamdan;
end
check    = norm(xn,2);
changex  = norm(xn,2);
sol1     = [iter,changex];
tic
while check > 1e-3
    xn      = xnp1;
    lamdan  = lamdanp1;
    iter    = iter+1;
    pn      = xn - lamdan*A2(xn,m,M);
    yn      = Proj_Poly(pn,m,k);
    xnp1    = PTn2(xn - lamdan*A2(yn,m,M),xn,yn,lamdan,m,M);
    rn1     = A2(xn,m,M) - A2(yn,m,M);
    rn2     = xn - yn;
    rn3     = xnp1 - yn;
    rn      = dot(rn1,rn3);
    if rn > 0
        lamdanp1 = min(miu*(norm(rn2,2)^2+norm(rn3,2)^2)/(2*rn),lamdan);
    else
        lamdanp1 = lamdan;
    end
    changex  = norm(xn,2);
    check    = norm(xn,2);
    sol1     = [sol1;[iter,changex]];
end
Time = toc;

% disp(['iter = ',num2str(iter)]);
% disp(['Time = ',num2str(Time)]);
% 
% figure
% loglog(sol1(:,1),sol1(:,2:end),'-*r','Linewidth',2,'MarkerSize',10)
% xlabel('Number of iterations','FontSize',16,'interpreter','latex')
% ylabel('$||x_{n+1}-x_n||_2$','interpreter','latex')
% I=legend('$||x_{n+1}-x_n||_2$');
% set(I,'interpreter','latex');
% box off
% grid on

