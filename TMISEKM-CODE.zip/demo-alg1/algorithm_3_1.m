%% algorithm_3_1.m
% 论文 Algorithm 3.1: Inertial Subgradient Extragradient Method with Viscosity
% 参考文献: Adamu et al. (2026), Journal of Scientific Computing

function [x_history, errors, phi_history, time_history] = algorithm_3_1(F, P_C, f, params)
    %% 默认参数
    clc
    if ~isfield(params, 'rho'); params.rho = 0.5; end
    if ~isfield(params, 'phi1'); params.phi1 = 0.5; end
    if ~isfield(params, 'mu'); params.mu = 0.5; end
    if ~isfield(params, 'kappa'); params.kappa = 0.95; end
    if ~isfield(params, 'max_iter'); params.max_iter = 1000; end
    if ~isfield(params, 'tol'); params.tol = 1e-10; end
    
    % 序列定义
    if ~isfield(params, 'sigma_n')
        params.sigma_n = @(n) 1/(n + 300);
    end
    if ~isfield(params, 'gamma_n')
        params.gamma_n = @(n) 1/(n+1)^3;
    end
    if ~isfield(params, 'epsilon_n')
        params.epsilon_n = @(n) 1/factorial(n+1);
    end
    
    rho_max = params.rho;
    phi = params.phi1;
    mu = params.mu;
    sigma_n = params.sigma_n;
    gamma_n = params.gamma_n;
    epsilon_n = params.epsilon_n;
    max_iter = params.max_iter;
    tol = params.tol;
    
    %% 初始化
    x_prev = params.x0;   % x_{n-1}
    x_curr = params.x1;   % x_n
    
    % 存储
    x_history = zeros(max_iter + 2, length(x_curr));
    errors = zeros(max_iter + 2, 1);
    phi_history = zeros(max_iter + 2, 1);
    time_history = zeros(max_iter + 2, 1);
    
    x_history(1, :) = x_prev';
    x_history(2, :) = x_curr';
    errors(1) = norm(x_prev);
    errors(2) = norm(x_curr);
    phi_history(1) = phi;
    phi_history(2) = phi;
    time_history(1) = 0;
    time_history(2) = 0;
    
    t_start = tic;
    
    %% 主循环
    for n = 2:max_iter + 1
        idx = n - 1;
        
        sigma = sigma_n(idx);
        epsilon = epsilon_n(idx);
        gamma = gamma_n(idx);
        
        % Step 1: 计算惯性参数 rho_n
        diff_norm = norm(x_curr - x_prev);
        if diff_norm > 1e-12
            rho_n = min(rho_max, epsilon / diff_norm);
        else
            rho_n = rho_max;
        end
        
        % 惯性点 w_n
        w = x_curr + rho_n * (x_curr - x_prev);
        
        % Step 2: 预测步 y_n = P_C(w_n - phi_n * F(w_n))
        Fw = F(w);
        y = P_C(w - phi * Fw);
        
        % Step 3: 停止条件检查
        if norm(y - w) < tol
            x_next = w;
            x_history(n+1, :) = x_next';
            errors(n+1) = norm(x_next);
            phi_history(n+1) = phi;
            time_history(n+1) = toc(t_start);
            break;
        end
        
        % Step 4: 构造半空间并计算 z_n
        a = w - phi * Fw - y;  % 半空间法向量
        z = w - phi * F(y);     % 先计算 w - phi*Fy
        z = project_onto_halfspace(a, y, z);
        
        % Step 5: 粘度更新 x_{n+1} = (1-sigma)*z + sigma*f(z)
        fz = f(z);
        x_next = (1 - sigma) * z + sigma * fz;
        
        % Step 6: 更新步长 phi_{n+1}
        Fw_minus_Fy = Fw - F(y);
        if norm(Fw_minus_Fy) > 1e-12
            phi_next = min(mu * norm(w - y) / norm(Fw_minus_Fy), phi + gamma);
        else
            phi_next = phi + gamma;
        end
        
        % 存储
        x_history(n+1, :) = x_next';
        errors(n+1) = norm(x_next);
        phi_history(n+1) = phi_next;
        time_history(n+1) = toc(t_start);
        
        % 收敛检查
        if norm(x_next - x_curr) < tol
            break;
        end
        
        % 更新
        x_prev = x_curr;
        x_curr = x_next;
        phi = phi_next;
    end
    
    % 截断
    x_history = x_history(1:n+1, :);
    errors = errors(1:n+1);
    phi_history = phi_history(1:n+1);
    time_history = time_history(1:n+1);
end