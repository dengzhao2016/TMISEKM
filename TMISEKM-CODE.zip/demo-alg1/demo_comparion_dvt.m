%% demo_DVT_comparison.m
% 复现 Thong (2026) 论文 Figure 1 风格的数值实验
% 图1(a): 完整误差收敛曲线 vs 迭代次数
% 图1(b): 误差 vs 时间

clear; clc; close all;

%% ==================== 问题设置 ====================
% 论文参数: C = {x: ||x|| <= 2}, F(x) = (3 - ||x||) * x
alpha = 2;
beta = 3;

% 算子 (强伪单调，非单调)
F = @(x) (beta - norm(x)) * x;

% 投影到球
P_C = @(x) (norm(x) <= alpha) * x + (norm(x) > alpha) * (alpha / norm(x)) * x;

%% ==================== 初始点 ====================
rng(42);
dim = 50;

% Khanh 2014 只需要一个初始点
x0 = randn(dim, 1); 
x0 = (alpha / norm(x0)) * x0 * 0.8;  % 初始点在球内

% 其他算法需要两个初始点（用于惯性项）
x1 = randn(dim, 1); 
x1 = (alpha / norm(x1)) * x1 * 0.6;

%% ==================== 公共参数 ====================
max_iter = 500;
tol = 1e-10;

% 对于固定步长模式，需要知道 gamma 和 L
% 对于 F(x) = (beta - ||x||)x:
%   L = beta + 2*alpha = 3 + 4 = 7
%   gamma = beta - alpha = 3 - 2 = 1
L_fixed = beta + 2 * alpha;      % Lipschitz常数 = 7
gamma_fixed = beta - alpha;       % 强伪单调模量 = 1

fprintf('问题参数: alpha=%d, beta=%d\n', alpha, beta);
fprintf('Lipschitz常数 L = %.2f, 强伪单调模量 γ = %.2f\n', L_fixed, gamma_fixed);
fprintf('最优固定步长 λ* = γ/L^2 = %.6f\n', gamma_fixed / (L_fixed^2));
fprintf('步长上界 2γ/L^2 = %.6f\n\n', 2*gamma_fixed / (L_fixed^2));

%% ==================== 运行算法 ====================

% 1. thong (one-step) - Thong 2026
fprintf('Running one-step ISE...\n');
p.mu = 0.95; p.rho1 = 0.01; p.alpha = 0.1;
p.d0 = x0; p.d1 = x1; p.max_iter = max_iter; p.tol = tol;
[d_hist1, err1, lambda_hist1, time1] = one_step_ise(F, P_C, p);
iter1 = length(err1) - 1;  % 从误差序列长度计算迭代次数

% 2. Proposed (two-step) - 双惯性变体
fprintf('Running two-step ISE...\n');
p2.mu = 0.95; p2.rho1 = 0.01; p2.alpha1 = 0.2; p2.alpha2 = 0.15;
p2.d0 = x0; p2.d1 = x1; p2.max_iter = max_iter; p2.tol = tol;
[d_hist2, err2, lambda_hist2, time2] = two_step_ise(F, P_C, p2);
iter2 = length(err2) - 1;

% 3. Khanh et al. (2014) - 使用变步长模式
fprintf('Running Khanh et al. (2014) - variable stepsize...\n');
k.use_fixed = false;
k.lambda = @(n) 1/(n+1);
k.d0 = x0;
k.max_iter = max_iter;
k.tol = tol;
[d_hist3, err3_var, lambda_hist3, time3_var] = khanh_2014(F, P_C, k);

% 3b. Khanh et al. (2014) - 使用固定步长模式
fprintf('Running Khanh et al. (2014) - fixed stepsize (optimal)...\n');
k_fixed.use_fixed = true;
k_fixed.gamma = gamma_fixed;
k_fixed.L = L_fixed;
k_fixed.d0 = x0;
k_fixed.max_iter = max_iter;
k_fixed.tol = tol;
[d_hist3f, err3_fixed, lambda_hist3f, time3_fixed] = khanh_2014(F, P_C, k_fixed);

% 4. Hieu & Thong (2018)
fprintf('Running Hieu & Thong (2018)...\n');
h.alpha = @(n) 1/(n+1); 
h.lambda = @(n) 1/(n+1);
h.d0 = x0; 
h.d1 = x1; 
h.max_iter = max_iter; 
h.tol = tol;
[d_hist4, err4, lambda_hist4, time4] = hieu_thong_2018(F, P_C, h);

% 5. Thong & Hieu (2018)
fprintf('Running Thong & Hieu (2018)...\n');
t.lambda = 0.01; 
t.beta = 0.7; 
t.d0 = x0; 
t.d1 = x1;
t.max_iter = max_iter; 
t.tol = tol;
[d_hist5, err5, lambda_hist5, time5] = thong_hieu_2018(F, P_C, t);

% 6. Algorithm 3.1 (Adamu et al. 2026)
fprintf('Running Algorithm 3.1 (Adamu et al. 2026)...\n');
% 粘度函数 f(x) = x (恒等映射，作为简单情况)
f_viscosity = @(x) 0.95*x;
params_alg31.x0 = x0;
params_alg31.x1 = x1;
params_alg31.max_iter = max_iter;
params_alg31.tol = tol;
params_alg31.rho = 0.5;
params_alg31.phi1 = 0.5;
params_alg31.mu = 0.65;
params_alg31.kappa = 0.95;
[x_hist31, err31, phi_hist31, time31] = algorithm_3_1(F, P_C, f_viscosity, params_alg31);
% 截断到与迭代次数匹配
err31 = err31(1:min(length(err31), max_iter+1));
time31 = time31(1:min(length(time31), max_iter+1));

%% ==================== 打印结果 ====================
fprintf('\n========== 结果对比 ==========\n');
fprintf('One-step ISE:            iter=%d, time=%.4fs, final err=%.2e\n', iter1, time1(end), err1(end));
fprintf('Two-step ISE:            iter=%d, time=%.4fs, final err=%.2e\n', iter2, time2(end), err2(end));
fprintf('Khanh (var):             iter=%d, time=%.4fs, final err=%.2e\n', length(err3_var)-1, time3_var(end), err3_var(end));
fprintf('Khanh (fixed, optimal):  iter=%d, time=%.4fs, final err=%.2e\n', length(err3_fixed)-1, time3_fixed(end), err3_fixed(end));
fprintf('Hieu & Thong:            iter=%d, time=%.4fs, final err=%.2e\n', length(err4)-1, time4(end), err4(end));
fprintf('Thong & Hieu:            iter=%d, time=%.4fs, final err=%.2e\n', length(err5)-1, time5(end), err5(end));
fprintf('Thong（2026）:           iter=%d, time=%.4fs, final err=%.2e\n', length(err31)-1, time31(end), err31(end));

%% ==================== 绘制 Figure 1 风格对比图 ====================

figure('Position', [100, 100, 600, 500]);

% ========== 图(a): 误差 vs 迭代次数 ==========

% 获取最大长度
max_len = max([length(err1), length(err2), length(err3_var), length(err4), length(err5), length(err31)]);

% 补齐到相同长度
e1 = [err1; nan(max_len - length(err1), 1)];
e2 = [err2; nan(max_len - length(err2), 1)];
e3_var = [err3_var; nan(max_len - length(err3_var), 1)];
e4 = [err4; nan(max_len - length(err4), 1)];
e5 = [err5; nan(max_len - length(err5), 1)];
e31 = [err31; nan(max_len - length(err31), 1)];

% 先画 Proposed (two-step-ise) —— 让它出现在图例第一位
semilogy(1:max_len, e2, 'r-', 'LineWidth', 2); hold on;
% 再画其他算法
semilogy(1:max_len, e1, 'b-', 'LineWidth', 2);
semilogy(1:max_len, e3_var, 'g-.', 'LineWidth', 2);
semilogy(1:max_len, e4, 'm:', 'LineWidth', 2);
semilogy(1:max_len, e5, 'k-', 'LineWidth', 1.5);
semilogy(1:max_len, e31, 'c-', 'LineWidth', 2);

xlabel('Iteration', 'FontSize', 12);
ylabel('Error (||d_n||)', 'FontSize', 12);
title('Error vs Iteration', 'FontSize', 14);

% 图例顺序与绘制顺序一致
legend('TIASEM', 'One-Step-ISE', ...
       'Khanh Alg.', 'Hieu Alg.', 'Thong Alg.', ...
       'Adamu Alg.', ...
       'Location', 'northeast', 'FontSize', 9);

grid on;
axis([0, max_iter, 1e-10, 1e1]);