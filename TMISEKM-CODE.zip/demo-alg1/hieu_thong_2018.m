function [d_history, errors, lambda_history, time_history] = hieu_thong_2018(F, P_C, params)
    % Hieu, D.V., Thong, D.V. (2018)
    % New extragradient-like algorithms for strongly pseudomonotone variational inequalities
    % J. Glob. Optim. 70, 385-399
    %
    % Inputs:
    %   F      - function handle for mapping F(x)
    %   P_C    - projection onto feasible set C
    %   params - structure containing parameters:
    %       .alpha     : inertia coefficient (sequence), default @(n) 1/(n+1)
    %       .lambda    : stepsize (sequence), default @(n) 1/(n+1)
    %       .d0        : initial point d0
    %       .d1        : initial point d1
    %       .max_iter  : max iterations, default 1000
    %       .tol       : tolerance, default 1e-8
    %
    % Outputs:
    %   d_history     - history of iterates
    %   errors        - history of errors (||d_n||)
    %   lambda_history - history of stepsizes
    %   time_history  - history of elapsed time at each iteration
clc
    % Default parameters
    if ~isfield(params, 'alpha'); params.alpha = @(n) 1/(n+1); end
    if ~isfield(params, 'lambda'); params.lambda = @(n) 1/(n+1); end
    if ~isfield(params, 'max_iter'); params.max_iter = 1000; end
    if ~isfield(params, 'tol'); params.tol = 1e-8; end

    alpha_fn = params.alpha;
    lambda_fn = params.lambda;
    max_iter = params.max_iter;
    tol = params.tol;

    % Initialize
    d_prev = params.d0;
    d_curr = params.d1;

    % Storage
    d_history = zeros(max_iter+2, length(d_curr));
    errors = zeros(max_iter+2, 1);
    lambda_history = zeros(max_iter+2, 1);
    time_history = zeros(max_iter+2, 1);

    d_history(1,:) = d_prev';
    d_history(2,:) = d_curr';
    errors(1) = norm(d_prev);
    errors(2) = norm(d_curr);
    lambda_history(1) = lambda_fn(1);
    lambda_history(2) = lambda_fn(2);
    time_history(1) = 0;
    time_history(2) = 0;

    % Start timing
    t_start = tic;

    % Main loop
    for n = 2:max_iter+1
        alpha = alpha_fn(n);
        lambda = lambda_fn(n);
        
        % Inertial extrapolation
        w = d_curr + alpha * (d_curr - d_prev);
        
        % Prediction step
        Fw = F(w);
        r = P_C(w - lambda * Fw);
        
        % Correction step
        Fr = F(r);
        d_next = P_C(w - lambda * Fr);
        
        % Store
        d_history(n+1,:) = d_next';
        errors(n+1) = norm(d_next);
        lambda_history(n+1) = lambda;
        time_history(n+1) = toc(t_start);
        
        % Check convergence
        if norm(d_next - d_curr) < tol || norm(d_next) < tol
            fprintf('Hieu-Thong: Converged at iteration %d\n', n-1);
            break;
        end
        
        % Update
        d_prev = d_curr;
        d_curr = d_next;
    end
    
    % Trim
    d_history = d_history(1:n+1,:);
    errors = errors(1:n+1);
    lambda_history = lambda_history(1:n+1);
    time_history = time_history(1:n+1);
end