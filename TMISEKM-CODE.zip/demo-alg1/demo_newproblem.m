%% demo_comparison_with_double_inertial.m
% 五个算法对比：One-Step ISE, Two-Step ISE, ThongHieu2018, 
%              HieuThong2018, 以及论文中的 Double Inertial Subgradient Extragradient (Alg. 1)
% 
% 问题：论文Example 1的扩展版本
%   C = {x ∈ R^n: 0 ≤ x₁ ≤ 1, x_i ≥ 0 for i≥2}  
%   F(x) = [0.6 - 0.5*x₁, x₂/(1+||x||), x₃/(1+||x||), ..., x_n/(1+||x||)]^T
%   
% 性质：
%   - 解：x* = 0
%   - 非单调（可证明）
%   - Condition 2 成立

clear; clc; close all;

%% ==================== 1. 问题设置 ====================
rng(2024);

% 问题维度
dim = 200;           % 维度
max_iter = 500;     % 最大迭代次数
tol = 1e-8;         % 收敛容差

% 可行集 C: x₁ ∈ [0,1], x_i ≥ 0 for i≥2
P_C = @(x) [max(0, min(1, x(1))); max(0, x(2:end))];

% F 算子（论文Example 1扩展版）
F = @(x) example1_extended_F(x);

% 初始点
x0 = [0.9; abs(randn(dim-1, 1)) * 0.8];
x1 = [0.7; abs(randn(dim-1, 1)) * 0.5];

%% ==================== 2. 验证问题性质 ====================
fprintf('========== 问题性质验证 ==========\n\n');

% 验证解
x_star = zeros(dim, 1);
Fx_star = F(x_star);
fprintf('1. 解验证:\n');
fprintf('   F(0) = [%.2f', Fx_star(1));
if dim > 2, fprintf(', %.2f, ...', Fx_star(2)); end
fprintf(']^T\n');
fprintf('   ⟨F(0), y-0⟩ = %.2f·y₁ ≥ 0 ✅ 对所有 y∈C\n', Fx_star(1));
fprintf('   所以 x* = 0 是解\n\n');

% 验证Condition 2
fprintf('2. Condition 2 验证 (⟨F(y), y-0⟩ ≥ 0 ∀y∈C):\n');
num_tests = 1000;
violations = 0;
for i = 1:num_tests
    y = rand(dim, 1);
    y(1) = rand();  % x₁ ∈ [0,1]
    y(2:end) = abs(randn(dim-1, 1)) * 2;
    Fy = F(y);
    val = dot(Fy, y);
    if val < -1e-10
        violations = violations + 1;
    end
end
if violations == 0
    fprintf('   ✅ 所有测试点满足 Condition 2\n\n');
else
    fprintf('   ⚠️ %d/%d 测试点违反\n\n', violations, num_tests);
end

% 验证非单调性
fprintf('3. 非单调性验证:\n');
x_test = [0.8; ones(dim-1,1)*0.6];
y_test = [0.2; zeros(dim-1,1)];
Fx = F(x_test);
Fy = F(y_test);
val_x = dot(Fx, y_test - x_test);
val_y = dot(Fy, y_test - x_test);
fprintf('   ⟨F(x), y-x⟩ = %.4f\n', val_x);
fprintf('   ⟨F(y), y-x⟩ = %.4f\n', val_y);
if val_x > 0 && val_y < 0
    fprintf('   ✅ F 不是单调的\n\n');
end

%% ==================== 3. 运行五个算法 ====================
fprintf('========== 运行五个算法 ==========\n\n');

results = struct();

% ----- Algorithm 1: Double Inertial Subgradient Extragradient (论文 Algorithm 1) -----
fprintf('[1/5] Double Inertial SEG (Yao et al. 2022, Alg. 1)...\n');
p1.x0 = x0; p1.x1 = x1;
p1.max_iter = max_iter; p1.tol = tol;
% 论文参数：epsilon > 2, delta < min{(epsilon-sqrt(2*epsilon))/epsilon, theta1}
% alpha_n in (0, 1/(1+epsilon)), theta_n in [0,1]
p1.epsilon = 2.001;           % epsilon ∈ (2, ∞)
p1.delta = 0.1;            % delta < min{(10-sqrt(20))/10, theta1} ≈ 0.553
p1.theta = 0.0002499;            % theta_n = theta (常数，论文允许 theta_n ∈ [0,1])
p1.alpha = 0.3332;           % alpha_n = alpha (常数，满足 0 < alpha < 1/(1+10) ≈ 0.091)
p1.mu = 0.1;               % mu ∈ (0,1)，用于自适应步长
p1.lambda1 = 1.1;          % 初始步长
tic;
[d1, err1, lam1, t1] = double_inertial_seg(F, P_C, p1);
t1_end = toc;
results.double_inertial.iter = length(err1)-1;
results.double_inertial.time = t1(end);
results.double_inertial.error = err1(end);
results.double_inertial.errors = err1;
results.double_inertial.times = t1;
fprintf('   迭代: %d, 时间: %.3fs, 误差: %.2e\n', results.double_inertial.iter, results.double_inertial.time, results.double_inertial.error);

% ----- Algorithm 2: One-Step ISE (Thong 2026) -----
fprintf('[2/5] One-Step ISE (Thong 2026)...\n');
p2.d0 = x0; p2.d1 = x1;
p2.max_iter = max_iter; p2.tol = tol;
p2.mu = 0.95; p2.rho1 = 0.5; p2.alpha = 0.3;
tic;
[d2, err2, rho2, t2] = one_step_ise(F, P_C, p2);
t2_end = toc;
results.one_step.iter = length(err2)-1;
results.one_step.time = t2(end);
results.one_step.error = err2(end);
results.one_step.errors = err2;
results.one_step.times = t2;
fprintf('   迭代: %d, 时间: %.3fs, 误差: %.2e\n', results.one_step.iter, results.one_step.time, results.one_step.error);

% ----- Algorithm 3: Two-Step ISE (Extended) -----
fprintf('[3/5] Two-Step ISE (Extended)...\n');
p3.d0 = x0; p3.d1 = x1;
p3.max_iter = max_iter; p3.tol = tol;
p3.mu = 0.95; p3.rho1 = 0.5; p3.alpha1 = 0.3; p3.alpha2 = 0.1;
tic;
[d3, err3, rho3, t3] = two_step_ise(F, P_C, p3);
t3_end = toc;
results.two_step.iter = length(err3)-1;
results.two_step.time = t3(end);
results.two_step.error = err3(end);
results.two_step.errors = err3;
results.two_step.times = t3;
fprintf('   迭代: %d, 时间: %.3fs, 误差: %.2e\n', results.two_step.iter, results.two_step.time, results.two_step.error);

% ----- Algorithm 4: Thong-Hieu 2018 (Inertial Subgradient Extragradient) -----
fprintf('[4/5] Thong-Hieu 2018...\n');
p5.d0 = x0; p5.d1 = x1;
p5.max_iter = max_iter; p5.tol = tol;
p5.lambda = 0.01;
p5.beta = 0.7;
tic;
[d5, err5, lam5, t5] = thong_hieu_2018(F, P_C, p5);
t5_end = toc;
results.thong_hieu.iter = length(err5)-1;
results.thong_hieu.time = t5(end);
results.thong_hieu.error = err5(end);
results.thong_hieu.errors = err5;
results.thong_hieu.times = t5;
fprintf('   迭代: %d, 时间: %.3fs, 误差: %.2e\n', results.thong_hieu.iter, results.thong_hieu.time, results.thong_hieu.error);

% ----- Algorithm 5: Hieu-Thong 2018 (New Extragradient-like) -----
fprintf('[5/5] Hieu-Thong 2018...\n');
p6.d0 = x0; p6.d1 = x1;
p6.max_iter = max_iter; p6.tol = tol;
p6.alpha = @(k) 1/(k+1);
p6.lambda = @(k) 1/(k+1);
tic;
[d6, err6, lam6, t6] = hieu_thong_2018(F, P_C, p6);
t6_end = toc;
results.hieu_thong.iter = length(err6)-1;
results.hieu_thong.time = t6(end);
results.hieu_thong.error = err6(end);
results.hieu_thong.errors = err6;
results.hieu_thong.times = t6;
fprintf('   迭代: %d, 时间: %.3fs, 误差: %.2e\n', results.hieu_thong.iter, results.hieu_thong.time, results.hieu_thong.error);

%% ==================== 4. 结果汇总表格 ====================
fprintf('\n========== 结果汇总 ==========\n');
fprintf('%-25s | %10s | %10s | %15s\n', '算法', '迭代次数', '时间(秒)', '最终误差');
fprintf('%s\n', repmat('-', 75, 1));
fprintf('%-25s | %10d | %10.4f | %15.2e\n', 'Double Inertial SEG', results.double_inertial.iter, results.double_inertial.time, results.double_inertial.error);
fprintf('%-25s | %10d | %10.4f | %15.2e\n', 'One-Step ISE', results.one_step.iter, results.one_step.time, results.one_step.error);
fprintf('%-25s | %10d | %10.4f | %15.2e\n', 'Two-Step ISE', results.two_step.iter, results.two_step.time, results.two_step.error);
fprintf('%-25s | %10d | %10.4f | %15.2e\n', 'Thong-Hieu 2018', results.thong_hieu.iter, results.thong_hieu.time, results.thong_hieu.error);
fprintf('%-25s | %10d | %10.4f | %15.2e\n', 'Hieu-Thong 2018', results.hieu_thong.iter, results.hieu_thong.time, results.hieu_thong.error);

%% ==================== 5. 绘图 ====================
figure('Position', [100, 100, 700, 500]);

% 子图1：迭代次数 vs 误差
% 先画你的算法 Two-Step ISE（让它出现在图例第一位）
semilogy(1:length(results.two_step.errors), results.two_step.errors, 'r-', 'LineWidth', 2); hold on;
% 再画其他算法
semilogy(1:length(results.double_inertial.errors), results.double_inertial.errors, 'c-', 'LineWidth', 1.5);
semilogy(1:length(results.one_step.errors), results.one_step.errors, 'b-', 'LineWidth', 1.5);
semilogy(1:length(results.thong_hieu.errors), results.thong_hieu.errors, 'g-.', 'LineWidth', 1.5);
semilogy(1:length(results.hieu_thong.errors), results.hieu_thong.errors, 'm-', 'LineWidth', 1.5);

xlabel('Iteration', 'FontSize', 12);
ylabel('Error ||x_n||', 'FontSize', 12);
title('Error vs Iteration', 'FontSize', 14);

% 图例顺序与绘图顺序一致：Two-Step ISE 放在第一个
legend('TIASEM', 'Yoy Alg.', 'One-Step-ISE', ...
       'Thong Alg.', 'Hieu Alg.', ...
       'Location', 'northeast', 'FontSize', 9);
grid on;
axis([0, max_iter, 1e-8, 1e1]);
%% ==================== 辅助函数 ====================
function y = example1_extended_F(x)
    % 论文Example 1扩展版
    n = length(x);
    norm_x = norm(x);
    y = zeros(n, 1);
    y(1) = 0.6 - 0.5 * x(1);
    if norm_x > 1e-12
        y(2:end) = x(2:end) / (1 + norm_x);
    else
        y(2:end) = x(2:end);
    end
end