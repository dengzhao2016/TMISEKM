function [d_history, errors, rho_history, time_history] = two_step_ise(F, P_C, params)
    % Two-step inertial subgradient extragradient method for non-monotone VIs
    %
    % Inputs:
    %   F      - function handle for mapping F(x)
    %   P_C    - projection onto feasible set C
    %   params - structure containing parameters:
    %       .mu      : in (0,1), default 0.95
    %       .rho1    : initial stepsize, default 0.01
    %       .alpha1  : first inertia coefficient, default 0.1
    %       .alpha2  : second inertia coefficient, default 0.05
    %       .d0      : initial point d0
    %       .d1      : initial point d1
    %       .max_iter: max iterations, default 1000
    %       .tol     : tolerance, default 1e-8
    %
    % Outputs:
    %   d_history   - history of iterates d_n
    %   errors      - history of errors (||d_n|| if solution is 0)
    %   rho_history - history of stepsizes
    %   time_history - history of elapsed time at each iteration
clc
    % Default parameters
    if ~isfield(params, 'mu'); params.mu = 0.95; end
    if ~isfield(params, 'rho1'); params.rho1 = 0.01; end
    if ~isfield(params, 'alpha1'); params.alpha1 = 0.1; end
    if ~isfield(params, 'alpha2'); params.alpha2 = 0.05; end
    if ~isfield(params, 'max_iter'); params.max_iter = 1000; end
    if ~isfield(params, 'tol'); params.tol = 1e-8; end

    mu = params.mu;
    alpha1 = params.alpha1;
    alpha2 = params.alpha2;
    max_iter = params.max_iter;
    tol = params.tol;

    % Initialize
    d_prev2 = params.d0;   % d_{n-2}
    d_prev1 = params.d1;   % d_{n-1}
    d_curr = params.d1;    % d_n
    rho = params.rho1;

    % For step size adaptation
    xn = @(n) 1/(n+1);
    yn = @(n) 1 + xn(n);
    alphan = @(n) 1/((n+1)^1.1);

    % Storage
    d_history = zeros(max_iter+2, length(d_curr));
    errors = zeros(max_iter+2, 1);
    rho_history = zeros(max_iter+2, 1);
    time_history = zeros(max_iter+2, 1);

    d_history(1,:) = d_prev2';
    d_history(2,:) = d_prev1';
    errors(1) = norm(d_prev2);
    errors(2) = norm(d_prev1);
    rho_history(1) = rho;
    rho_history(2) = rho;
    time_history(1) = 0;
    time_history(2) = 0;

    % Start timing
    t_start = tic;

    % Main loop
    for n = 2:max_iter+1
        % Two-step inertia
        w = d_curr + alpha1*(d_curr - d_prev1) + alpha2*(d_prev1 - d_prev2);

        % Prediction step
        Fw = F(w);
        r = P_C(w - rho * Fw);

        % Construct half-space T_n and project
        Fr = F(r);
        Tn_proj = @(x) project_onto_halfspace(w, rho, Fw, r, x);
        d_next = Tn_proj(w - rho * Fr);

        % Adaptive stepsize update
        Fw_minus_Fr = Fw - Fr;
        if norm(Fw_minus_Fr) > 1e-12
            rho_next = min((xn(n) + yn(n)*mu) * norm(w - r) / norm(Fw_minus_Fr), ...
                           (1 + alphan(n)) * rho);
        else
            rho_next = (1 + alphan(n)) * rho;
        end

        % Store history
        d_history(n+1,:) = d_next';
        errors(n+1) = norm(d_next);
        rho_history(n+1) = rho_next;
        time_history(n+1) = toc(t_start);

        % Check convergence
        if norm(d_next - d_curr) < tol && norm(d_curr) < tol
            fprintf('Converged at iteration %d\n', n-1);
            break;
        end

        % Update for next iteration
        d_prev2 = d_prev1;
        d_prev1 = d_curr;
        d_curr = d_next;
        rho = rho_next;
    end

    % Trim history
    d_history = d_history(1:n+1,:);
    errors = errors(1:n+1);
    rho_history = rho_history(1:n+1);
    time_history = time_history(1:n+1);
end

function y = project_onto_halfspace(w, rho, Fw, r, x)
    % Projection onto half-space T_n = { x : <w - rho*Fw - r, x - r> <= 0 }
    a = w - rho * Fw - r;
    if dot(a, x - r) <= 0
        y = x;
    else
        y = x - (dot(a, x - r) / dot(a, a)) * a;
    end
end