function [d_history, errors, lambda_history, time_history] = khanh_2014(F, P_C, params)
    % Khanh, P.D., Vuong, P.T. (2014)
    % Modified projection method for strongly pseudomonotone variational inequalities
    % J. Glob. Optim. 58, 341-350
    %
    % Algorithm 3.1: Basic projection method with variable stepsizes
    %   u^{k+1} = P_C(u^k - lambda_k * F(u^k))
    %
    % Two versions are supported:
    %   1. Fixed stepsize: lambda in (0, 2*gamma/L^2)  (Theorem 4.1)
    %   2. Variable stepsize: lambda_n -> 0, sum lambda_n = inf  (Theorem 5.1)
    %
    % Inputs:
    %   F      - function handle for mapping F(x)
    %   P_C    - projection onto feasible set C
    %   params - structure containing parameters:
    %       .lambda      : stepsize (scalar for fixed, or function handle for variable)
    %                       default @(n) 1/(n+1)
    %       .use_fixed   : boolean, true for fixed stepsize, false for variable
    %                       default false
    %       .gamma       : strong pseudomonotonicity modulus (for fixed stepsize)
    %                       default 1 (user should provide correct value)
    %       .L           : Lipschitz constant (for fixed stepsize)
    %                       default 1 (user should provide correct value)
    %       .d0          : initial point d0
    %       .max_iter    : max iterations, default 1000
    %       .tol         : tolerance, default 1e-8
    %
    % Outputs:
    %   d_history     - history of iterates
    %   errors        - history of errors (||d_n||)
    %   lambda_history - history of stepsizes
    %   time_history  - history of elapsed time at each iteration
clc
    % Default parameters
    if ~isfield(params, 'use_fixed'); params.use_fixed = false; end
    if ~isfield(params, 'max_iter'); params.max_iter = 1000; end
    if ~isfield(params, 'tol'); params.tol = 1e-8; end
    if ~isfield(params, 'gamma'); params.gamma = 1; end
    if ~isfield(params, 'L'); params.L = 1; end

    max_iter = params.max_iter;
    tol = params.tol;
    gamma = params.gamma;
    L = params.L;

    % Stepsize configuration
    if params.use_fixed
        % Fixed stepsize (Theorem 4.1)
        if ~isfield(params, 'lambda')
            % Optimal stepsize according to Remark 4.2: lambda = gamma/L^2
            params.lambda = gamma / (L^2);
            fprintf('Khanh: Using optimal fixed stepsize lambda = %.4f\n', params.lambda);
        end
        lambda_fn = @(n) params.lambda;
        
        % Verify stepsize condition (Theorem 4.1)
        if params.lambda >= 2*gamma/(L^2)
            warning('Khanh: lambda = %.4f >= 2*gamma/L^2 = %.4f, convergence not guaranteed', ...
                params.lambda, 2*gamma/(L^2));
        end
    else
        % Variable stepsize (Theorem 5.1)
        % Must satisfy: lambda_n -> 0 and sum lambda_n = inf
        if ~isfield(params, 'lambda')
            % Default: lambda_n = 1/(n+1) (satisfies conditions)
            params.lambda = @(n) 1/(n+1);
        elseif ~isa(params.lambda, 'function_handle')
            error('For variable stepsize, params.lambda must be a function handle');
        end
        lambda_fn = params.lambda;
    end

    % Initialize
    d_curr = params.d0;

    % Storage
    d_history = zeros(max_iter+1, length(d_curr));
    errors = zeros(max_iter+1, 1);
    lambda_history = zeros(max_iter+1, 1);
    time_history = zeros(max_iter+1, 1);

    d_history(1,:) = d_curr';
    errors(1) = norm(d_curr);
    lambda_history(1) = lambda_fn(1);
    time_history(1) = 0;

    % Start timing
    t_start = tic;

    % Main loop
    for n = 1:max_iter
        lambda_n = lambda_fn(n);
        
        % Basic projection iteration (Algorithm 3.1 core)
        Fd = F(d_curr);
        d_next = P_C(d_curr - lambda_n * Fd);
        
        % Store
        d_history(n+1,:) = d_next';
        errors(n+1) = norm(d_next);
        lambda_history(n+1) = lambda_n;
        time_history(n+1) = toc(t_start);
        
        % Check convergence
        if norm(d_next - d_curr) < tol || norm(d_next) < tol
            fprintf('Khanh: Converged at iteration %d\n', n);
            break;
        end
        
        % Update
        d_curr = d_next;
    end
    
    % Trim
    d_history = d_history(1:n+1,:);
    errors = errors(1:n+1);
    lambda_history = lambda_history(1:n+1);
    time_history = time_history(1:n+1);
end