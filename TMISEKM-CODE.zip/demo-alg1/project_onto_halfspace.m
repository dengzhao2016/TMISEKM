%% 辅助函数: 投影到半空间
function y = project_onto_halfspace(a, r, x)
    % 投影到 T = {x: <a, x - r> <= 0}
    if dot(a, x - r) <= 0
        y = x;
    else
        y = x - (dot(a, x - r) / dot(a, a)) * a;
    end
end