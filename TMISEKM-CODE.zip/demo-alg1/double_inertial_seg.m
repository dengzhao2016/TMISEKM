function [x_history, errors, lambda_history, time_history] = double_inertial_seg(F, P_C, params)
    % Double Inertial Subgradient Extragradient Method (Yao et al. 2022, Algorithm 1)
    %
    % 论文: "Subgradient Extragradient Method with Double Inertial Steps 
    %        for Variational Inequalities"
    %
    % Inputs:
    %   F      - function handle for mapping F(x) (= A(x) in paper)
    %   P_C    - projection onto feasible set C
    %   params - structure containing parameters:
    %       .epsilon : > 2, 控制 delta 和 alpha 的上界
    %       .delta   : 第一个惯性系数 [0, min{(eps-sqrt(2*eps))/eps, theta1})
    %       .theta   : 第二个惯性系数 [0,1] (论文允许 theta_n = 1)
    %       .alpha   : 松弛参数 (0, 1/(1+epsilon))
    %       .mu      : (0,1), 用于自适应步长
    %       .lambda1 : 初始步长 > 0
    %       .x0      : 初始点 x_0
    %       .x1      : 初始点 x_1
    %       .max_iter: 最大迭代次数
    %       .tol     : 收敛容差
    %
    % Outputs:
    %   x_history    - history of iterates x_n
    %   errors       - history of errors (||x_n|| if solution is 0)
    %   lambda_history - history of stepsizes lambda_n
    %   time_history - history of elapsed time
clc
    % Default parameters
    if ~isfield(params, 'epsilon'); params.epsilon = 10; end
    if ~isfield(params, 'delta'); params.delta = 0.1; end
    if ~isfield(params, 'theta'); params.theta = 0.5; end
    if ~isfield(params, 'alpha'); params.alpha = 0.05; end
    if ~isfield(params, 'mu'); params.mu = 0.9; end
    if ~isfield(params, 'lambda1'); params.lambda1 = 1.0; end
    if ~isfield(params, 'max_iter'); params.max_iter = 1000; end
    if ~isfield(params, 'tol'); params.tol = 1e-8; end

    epsilon = params.epsilon;
    delta = params.delta;
    theta = params.theta;
    alpha = params.alpha;
    mu = params.mu;
    lambda = params.lambda1;
    max_iter = params.max_iter;
    tol = params.tol;

    % 验证参数条件
    delta_max = min((epsilon - sqrt(2*epsilon))/epsilon, theta);
    alpha_max = 1/(1+epsilon);
    if delta >= delta_max
        warning('delta (%.4f) should be < %.4f. Adjusting...', delta, delta_max);
        delta = 0.9 * delta_max;
    end
    if alpha >= alpha_max
        warning('alpha (%.4f) should be < %.4f. Adjusting...', alpha, alpha_max);
        alpha = 0.9 * alpha_max;
    end
    fprintf('      [参数] epsilon=%.2f, delta=%.4f, theta=%.4f, alpha=%.4f, mu=%.2f, lambda1=%.4f\n', ...
            epsilon, delta, theta, alpha, mu, lambda);

    % Initialize
    x_prev = params.x0;   % x_{n-1}
    x_curr = params.x1;   % x_n

    % Storage
    dim = length(x_curr);
    x_history = zeros(max_iter+2, dim);
    errors = zeros(max_iter+2, 1);
    lambda_history = zeros(max_iter+2, 1);
    time_history = zeros(max_iter+2, 1);

    x_history(1,:) = x_prev';
    x_history(2,:) = x_curr';
    errors(1) = norm(x_prev);
    errors(2) = norm(x_curr);
    lambda_history(1) = lambda;
    lambda_history(2) = lambda;
    time_history(1) = 0;
    time_history(2) = 0;

    % Start timing
    t_start = tic;

    % Main loop (n starts from 1, but we use indices 2,3,... for x_n)
    for n = 2:max_iter+1
        % ===== Step 1: Double inertial extrapolation =====
        % z_n = x_n + delta * (x_n - x_{n-1})
        z_n = x_curr + delta * (x_curr - x_prev);
        
        % w_n = x_n + theta * (x_n - x_{n-1})  (论文允许 theta_n = 1)
        w_n = x_curr + theta * (x_curr - x_prev);

        % ===== Step 2: Prediction step =====
        % y_n = P_C(w_n - lambda * A(w_n))
        Fw = F(w_n);
        y_n = P_C(w_n - lambda * Fw);

        % ===== Stopping criterion =====
        % If w_n = y_n = x_n, STOP
        if norm(w_n - y_n) < 1e-14 && norm(y_n - x_curr) < 1e-14
            fprintf('      [停止] w_n = y_n = x_n at iteration %d\n', n-1);
            break;
        end

        % ===== Step 3: Adaptive stepsize update =====
        % lambda_{n+1} = min{ mu*||w_n - y_n|| / ||A(w_n) - A(y_n)||, lambda_n }
        % if A(w_n) != A(y_n), else lambda_{n+1} = lambda_n
        Fy = F(y_n);
        diff_F = Fw - Fy;
        diff_wy = w_n - y_n;
        
        if norm(diff_F) > 1e-12
            lambda_next = min(mu * norm(diff_wy) / norm(diff_F), lambda);
        else
            lambda_next = lambda;
        end

        % ===== Step 4: Construct half-space T_n =====
        % T_n = { w ∈ H : <w_n - lambda*A(w_n) - y_n, w - y_n> <= 0 }
        % Project onto T_n: P_{T_n}(w_n - lambda * A(y_n))
        
        % Compute the point to project: v = w_n - lambda * A(y_n)
        v = w_n - lambda * Fy;
        
        % Projection onto half-space T_n
        a = w_n - lambda * Fw - y_n;  % normal vector
        b = y_n;
        
        % P_{T_n}(v) = v - max{0, <a, v-b>} / ||a||^2 * a
        if dot(a, v - b) <= 0
            u_n = v;  % Already in T_n
        else
            u_n = v - (dot(a, v - b) / dot(a, a)) * a;
        end

        % ===== Step 5: Relaxation step =====
        % x_{n+1} = (1 - alpha) * z_n + alpha * u_n
        x_next = (1 - alpha) * z_n + alpha * u_n;

        % Store history
        x_history(n+1,:) = x_next';
        errors(n+1) = norm(x_next);
        lambda_history(n+1) = lambda_next;
        time_history(n+1) = toc(t_start);

        % Check convergence
        if norm(x_next - x_curr) < tol && norm(x_next) < tol
            fprintf('      [收敛] Converged at iteration %d\n', n-1);
            break;
        end

        % Update for next iteration
        x_prev = x_curr;
        x_curr = x_next;
        lambda = lambda_next;
    end

    % Trim history
    x_history = x_history(1:n+1,:);
    errors = errors(1:n+1);
    lambda_history = lambda_history(1:n+1);
    time_history = time_history(1:n+1);
end