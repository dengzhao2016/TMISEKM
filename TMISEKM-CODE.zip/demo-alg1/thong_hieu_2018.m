function [d_history, errors, lambda_history, time_history] = thong_hieu_2018(F, P_C, params)
    % Thong, D.V., Hieu, D.V. (2018)
    % Modified subgradient extragradient method for inequality variational problems
    % Numer. Algorithms 79, 597-610
    %
    % Inputs:
    %   F      - function handle for mapping F(x)
    %   P_C    - projection onto feasible set C
    %   params - structure containing parameters:
    %       .lambda    : fixed stepsize, default 0.01
    %       .beta      : inertia coefficient, default 0.7
    %       .d0        : initial point d0
    %       .d1        : initial point d1
    %       .max_iter  : max iterations, default 1000
    %       .tol       : tolerance, default 1e-8
    %
    % Outputs:
    %   d_history     - history of iterates
    %   errors        - history of errors (||d_n||)
    %   lambda_history - history of stepsizes (constant)
    %   time_history  - history of elapsed time at each iteration
clc
    % Default parameters
    if ~isfield(params, 'lambda'); params.lambda = 0.01; end
    if ~isfield(params, 'beta'); params.beta = 0.7; end
    if ~isfield(params, 'max_iter'); params.max_iter = 1000; end
    if ~isfield(params, 'tol'); params.tol = 1e-8; end

    lambda = params.lambda;
    beta = params.beta;
    max_iter = params.max_iter;
    tol = params.tol;

    % Initialize
    d_prev = params.d0;
    d_curr = params.d1;

    % Storage
    d_history = zeros(max_iter+2, length(d_curr));
    errors = zeros(max_iter+2, 1);
    lambda_history = zeros(max_iter+2, 1);
    time_history = zeros(max_iter+2, 1);

    d_history(1,:) = d_prev';
    d_history(2,:) = d_curr';
    errors(1) = norm(d_prev);
    errors(2) = norm(d_curr);
    lambda_history(1) = lambda;
    lambda_history(2) = lambda;
    time_history(1) = 0;
    time_history(2) = 0;

    % Start timing
    t_start = tic;

    % Main loop
    for n = 2:max_iter+1
        % Inertial extrapolation
        w = d_curr + beta * (d_curr - d_prev);
        
        % Prediction step
        Fw = F(w);
        r = P_C(w - lambda * Fw);
        
        % Construct half-space T_n
        a = w - lambda * Fw - r;
        
        % Project onto half-space
        d_next = project_onto_halfspace(a, r, w - lambda * F(r));
        
        % Store
        d_history(n+1,:) = d_next';
        errors(n+1) = norm(d_next);
        lambda_history(n+1) = lambda;
        time_history(n+1) = toc(t_start);
        
        % Check convergence
        if norm(d_next - d_curr) < tol || norm(d_next) < tol
            fprintf('Thong-Hieu: Converged at iteration %d\n', n-1);
            break;
        end
        
        % Update
        d_prev = d_curr;
        d_curr = d_next;
    end
    
    % Trim
    d_history = d_history(1:n+1,:);
    errors = errors(1:n+1);
    lambda_history = lambda_history(1:n+1);
    time_history = time_history(1:n+1);
end